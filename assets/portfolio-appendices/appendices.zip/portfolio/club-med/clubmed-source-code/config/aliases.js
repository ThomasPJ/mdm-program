/*
 * to avoid "../../../" relative requires, we have aliases in place,
 * they are configured here.
 */
var aliases = {
  "views" : "src/scripts/views",
  "models" : "src/scripts/models",
  "utils" : "src/scripts/utils",
  "dispatcher" : "src/scripts/dispatcher"
}

module.exports = aliases
