var path = require("path")
var fs = require("fs")

var aliases = require("./aliases")
var moduleNames = Object.keys(aliases)

moduleNames.forEach(function(moduleName){
  var dest = path.resolve(__dirname, "../node_modules/", moduleName)
  fs.lstat(dest, function(err, stats){
    if(err) {
      fs.symlinkSync(
        path.resolve(__dirname, "../src/scripts/" + moduleName),
        dest,
        "dir"
      )
      return
    }
  })
})

