var path = require("path")
var fs = require("fs")

var gulp = require("gulp")
var plumber = require("gulp-plumber")
var gutil = require("gulp-util")
var source = require("vinyl-source-stream")
var buffer = require("vinyl-buffer")
var sourcemaps = require("gulp-sourcemaps")
var through = require("through2")
var livereload = require("gulp-livereload")
var open = require("opn")
var glob = require("glob")
var _ = require("lodash")
var xml2js = require('xml2js')
var extReplace = require('gulp-ext-replace')

var cssnext = require("gulp-cssnext")
var insert = require("gulp-insert")
var minifyHTML = require('gulp-minify-html')
var browserify = require("browserify")
var envify = require('envify/custom')
var watchify = require("watchify")
var reactify = require("reactify")
var iconfont = require("gulp-iconfont")
var deploy = require('gulp-gh-pages')

var IS_DEV_MODE = process.argv.indexOf("--dev") > -1
var __VERSION__ = require("./package.json").version
var LANG = 'en'

var BANNER = "\
/**\n\
 * ClubMed Luxe v" + __VERSION__ + "\n\
 * Copyright 2015, Altima\n\
 */\n\n"

gulp.task("stylesheets", function(){
  return gulp.src("src/stylesheets/index.css")
    .pipe(plumber())
    .pipe(cssnext({
      from : "src/stylesheets/index.css",
      sourcemap : true,
      compress : !IS_DEV_MODE,
      features : {
        import : {
          path : ["src/stylesheets/", "node_modules/"]
        }
      }
    }))
    .pipe(insert.prepend(BANNER))
    .pipe(gulp.dest("dist/animationAssets/stylesheets"))
    .pipe(livereload())
})


gulp.task("assets", function(){
  return gulp.src("src/assets/**/*")
    .pipe(gulp.dest("dist/animationAssets"))
    .pipe(livereload())
})

gulp.task("lang", function(){
  return gulp.src("src/lang/**/*.json")
    .pipe(gulp.dest("dist/animationAssets/lang"))
    .pipe(livereload())
})

gulp.task("cm-assets", function(){
  return gulp.src("src/cm-assets/**/*")
    .pipe(gulp.dest("dist/cm/home"))
    .pipe(livereload())
})

gulp.task("public", function(){
  return gulp.src("src/public/**/*")
    .pipe(gulp.dest("dist"))
    .pipe(livereload())
})


const slideURL = [
  "1",
  "2",
  "3",
  "4",
  "5",
  "6",
]
require('es6-shim')


require('node-jsx').install({harmony: true})
var React = require('react')
var Router = require('react-router')
var routes = require('./src/scripts/routes')

if(IS_DEV_MODE) {
  process.env.NODE_ENV = 'development'
}

gulp.task("pages", function() {


  glob("src/lang/**.json", function(err, list) {
    list.forEach(function(filename) {
      const lang = path.parse(filename).name
      var data = ""
      fs.mkdir('dist/' + lang + '/', function(){
        fs.createReadStream(filename)
          .on("data", function(chunk) { data += chunk })
          .on("end", function() {
            var route = routes(lang)
            var childrenRoute = route.props.children
            childrenRoute.forEach(function(childRoute, i) {
              var url = childRoute.props.path
              Router.run(
                route,
                route.props.path + url,
                function(Handler) {
                  const writeStream = fs.createWriteStream('dist/' +lang+ '/' +url)
                  writeStream.write("<!DOCTYPE html>")
                  writeStream.write(React.renderToString(React.createElement(Handler, {
                    i18n: JSON.parse(data),
                    lang: lang,
                    langRoute: route
                  })))
                  writeStream.end()
                }
              )
            })
          })
      })
    })
  })
})


if(IS_DEV_MODE) {
  var bundler = watchify(
    browserify(
      {
        entries : [path.resolve(__dirname, "src/scripts/index.js")],
        debug : true
      },
      watchify.args
    )
  )
  bundler.on("update", bundle)
} else {
  var bundler = browserify(
    path.resolve(__dirname, "src/scripts/index.js")
  )
}

var testBundler = browserify()

Array(bundler, testBundler)
  .forEach(function(br){

    br.require(
      path.resolve(__dirname, "src/scripts/index.js"),
      {expose : "app"}
    )



    br.transform("reactify", {
      es6 : true,
      global : true
    })

    br.transform(envify({NODE_ENV: IS_DEV_MODE ? 'development' : 'production'}))

    br.transform(function(file) {
      return through(
        {
          objectMode : true
        },
        function(chunk, enc, cb) {
          var transformed = chunk.toString()
            .replace(/__DEV__/g, String(testBundler == br || IS_DEV_MODE))
            .replace(/__VERSION__/g, "\"" + __VERSION__ + "\"")
          return cb(null, transformed)
        }
      )
    }, {
      global : true
    })
  })


if(!IS_DEV_MODE) {
  bundler.transform("uglifyify", {global: true})
}

function bundle() {
  return bundler.bundle()
    .on("error", gutil.log.bind(gutil, "browserify error"))
    .pipe(source("bundle.js"))
    .pipe(insert.wrap('(function() {var define = undefined;var require = undefined;', '})()'))
    .pipe(insert.prepend(BANNER))
    .pipe(buffer())
    .pipe(sourcemaps.init({loadMaps:true}))
    .pipe(sourcemaps.write("./"))
    .pipe(gulp.dest("dist/animationAssets/scripts"))
    .pipe(livereload())
}

gulp.task("watch", function(){
  var connect = require("connect")
  livereload.listen({
    port : 4243
  })
  require("http")
    .createServer(
      connect()
        .use(require("connect-livereload")({port : 4243}))
        .use(require("serve-static")("dist"))
    )
    .listen(8000)
    .on("listening", function(){
      gutil.log("Started connect web server on http://localhost:8000")
    })

  gulp.watch(["src/stylesheets/**/*.css"], ["stylesheets"])
  gulp.watch(["src/scripts/**/*.js"], ["pages", "scripts"])
  gulp.watch(
    ["stylesheets"]
  )
  gulp.watch(
    ["src/assets/**/*"],
    ["assets"]
  )
  gulp.watch(
    ["src/public/**/*"],
    ["public"]
  )
})

gulp.task("scripts", bundle)

gulp.task("lint", function(cb) {
  glob("src/scripts/**/*.js", function(err, files) {
    var index = 0
    files.forEach(function(file) {
      var jshint = require("child_process").exec(
        path.resolve(
          __dirname,
          "node_modules/.bin/jshint"
        ) + " " + file
      )
      jshint.stdout
        .on("end", function() {
          if(++index == files.length) {
            cb()
          }
         })
        .on("data", function(chunk){
          console.log(gutil.colors.yellow("[jshint]"))
          console.log(gutil.colors.red(chunk))
        })
    })
  })
})


gulp.task('deploy', function () {
    return gulp.src('./dist/**/*')
        .pipe(deploy({}));
});

gulp.task("default", ["public", "assets", "lang", "cm-assets", "stylesheets", "scripts", "pages"])
gulp.task("dev", ["default", "watch"], function(cb){
  return cb(open("http://localhost:8000/"))
})
