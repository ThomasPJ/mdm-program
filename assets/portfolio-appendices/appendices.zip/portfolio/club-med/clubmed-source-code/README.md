# Club Med - luxe animation

## HTML
Additional HTML should be between the ```<!-- Start : Remove div below -->```and the ```<!-- End : Remove div below -->```.

## Assets
All the assets for the animation must be within a single folder, `animationAssets`. There may be several subfolders, of course.
Do note add files to the existing `css` and `images` folders.
E.g.

```
|-index.html
|-animationAssets/
    |- // put your own css, js, jpg, etc, files here
|-css/
    |- // do not put additional files here
|-images/
    |- // do not put additional files here
```


## Getting started

Install dependencies with `npm install`, and run the server `npm start`.

## Slides Templates

Templates can be found in `src/components/`. The slides templates are contained in the `src/components/slides/`.

## Deploying

To deploy to gh-pages, run `gulp && gulp deploy`.
