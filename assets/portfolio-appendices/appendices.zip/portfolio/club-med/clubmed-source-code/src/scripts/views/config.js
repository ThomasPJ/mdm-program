module.exports = {
	START_NEXT_ANIMATION_AT: 0.35,
	enums: {
		ANIMATION_STATE: {
		  FORWARDS: 1,
		  REVERSING: -1,
		  IN_DELAY: 0
		}
	}

}