var Config = {
	SLIDING_DURATION: 1,
	// assetsServer: 'http://ns.clubmed.com/fbs/2015/133/Luxe'
	assetsServer: process.env.NODE_ENV === 'development' ? '' : '/clubmed-luxe'
}

module.exports = Config