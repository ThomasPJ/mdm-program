module.exports = function() {
  var tspans = this.target;

  [].forEach.call(tspans, function(tspan) {
    var x     = tspan.getAttribute('x');
    var init  = tspan.getAttribute('data-init');


    if (init && x <= init) {
      if (x > init) {
        tspan.setAttribute('x', parseInt(init));
      }
      else {
        tspan.setAttribute('x', parseInt(x) + 3.5);
      }
    }
    else if (!init) {
      tspan.setAttribute('data-init', parseInt(x));
      tspan.setAttribute('x', parseInt(x) - 100);
    }
  });
};