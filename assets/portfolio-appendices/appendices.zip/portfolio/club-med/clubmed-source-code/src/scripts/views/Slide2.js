var React = require('react')
	, CmlSlide = require('./CmlSlide')
	, config = require('../config')
	, moveNode = require('../utils/moveNode');

if(typeof document !== 'undefined') {
	var gsap = require('gsap')
}

var INTRO_DURATION = 1.1
    , HEXES_DURATION = 0.8
    , HEXES_DELAY = 0.125
    , SHADOW_DURATION = 1.2
    , SHADOW_DELAY = 0.6
    , CONTENT_DURATION = 3.0
    , CONTENT_DELAY = 0.5
    , CONTENT_SLIDE_DISTANCE = 20
    , REPEAT_DELAY = 8
    , BG_FADE_DELAY = 2
    , BG_FADE_DURATION = 0.5
    , SHADOW_FADE_DURATION = 1.5
    , FADE_OUT_SHADOW_DURATION = 2
    , FADE_OUT_BG_DURATION = 2
    , START_NEXT_ANIMATION_AT = 0.75

var shapes, shapes2
	, preheader, title, subtitle, body
	, footer, bg1, bg2

module.exports = React.createClass({
	mixins: [CmlSlide],

	slideNum: 2,
	viewBox: "50 0 1400 1122",
	masks: {
		bg: [
      {fillOpacity:"1.0", r:"39", cx:"1058", cy:"666"},
      {fillOpacity:"0.8", r:"59", cx:"1117", cy:"666"},
      {fillOpacity:"0.3", d:"M1018,666 A156.5,156.5 0 0,0 1331 666 Z"},
      {fillOpacity:"0.3", d:"M919,666 A411,411 0 0,1 1741 666 Z"},
      {fillOpacity:"0.3", r:"156", cx:"1175", cy:"666"},
      {fillOpacity:"0.4", r:"98", cx:"1019", cy:"666"},
      {fillOpacity:"0.4", r:"254", cx:"922", cy:"666"},
      {fillOpacity:"0.3", r:"410", cx:"1331", cy:"666"},
      {fillOpacity:"0.3", r:"665", cx:"667", cy:"667"},
      {fillOpacity:"0.6", d:"M1,666 A665,665 0 0,1 1331 666 Z"}
		],
		extra: [
      {fillOpacity:"1.0", r:"39", cx:"1058", cy:"666"},
      {fillOpacity:"0.8", r:"59", cx:"1117", cy:"666"},
      {fillOpacity:"0.3", d:"M1018,666 A156.5,156.5 0 0,0 1331 666 Z"},
      {fillOpacity:"0.5", r:"98", cx:"1019", cy:"666"},
      {fillOpacity:"0.3", r:"156", cx:"1175", cy:"666"},
      {fillOpacity:"1.0", r:"410", cx:"1331", cy:"666"},
		]
	},

	images: {
		bg: [
			{
				src: config.assetsServer + '/animationAssets/images/slide3-hero-a.jpg',
				x:-205,
				y:-50,
				width:2000,
				height:1388
			},
			{
				src: config.assetsServer + '/animationAssets/images/slide3-hero-b.jpg',
				x:-230,
				y:100,
				width:1920,
				height:1000
			}
		],
		extra: []
	},

	textOptions: {
		init: {
			x: 1200,
			y: 230,
		},
		dy: {
			preheader: 40,
			titleTopMargin: 40,
			title: 28,
			subtitle: 17,
			body: 19
		},
		x: (y) => {
			return (0.0035 * (y-230) * (y-230) - 2 * (y-200) + 1200) + 30
		},
		textAnchor: 'end'
	},

	footerOptions: {
		init: {
			x: 600,
			y: 720,
		},
		dy: {
			footer: 13
		},
		x: (y) => {
			return 0.0025 * (y-720) * (y-720) + 0.07 * (y-230) + 600
		},
		textAnchor: 'end'
	},

	start(isMovingUp) {
		if(isMovingUp === true) {
			var slidingTimeline = new TimelineMax
			slidingTimeline.from(this.getDOMNode(), config.SLIDING_DURATION, {top: '100%'})
		} else if (isMovingUp === false) {
			var slidingTimeline = new TimelineMax
			slidingTimeline.from(this.getDOMNode(), config.SLIDING_DURATION, {top: '-100%'})
		}
		var svg = this.getDOMNode()
		svg.style.display = 'block'

		shapes = svg.querySelectorAll('.cml-slide-shape-0')
		shapes2 = svg.querySelectorAll('.cml-slide-shape-1')
		preheader = svg.querySelectorAll('.cml-slide__preheader')
		title = svg.querySelectorAll('.cml-slide__title')
		subtitle = svg.querySelectorAll('.cml-slide__subtitle')
		body = svg.querySelectorAll('.cml-slide__body')
		footer = svg.querySelectorAll('.cml-slide__footer')
		bg1 = svg.querySelector('#bg-0')
		bg2 = svg.querySelector('#bg-1')

		/** restore opacities **/
		bg2.style.opacity = 0


		/* version text et anims asynchrones */
		// var initTimeline = new TimelineMax
		// initTimeline
		// 	.to(preheader, CONTENT_DURATION, {fillOpacity: 1, onUpdate: moveNode}, "content")
		// 	.to(title, CONTENT_DURATION, {fillOpacity: 1, onUpdate: moveNode}, "content+=" + CONTENT_DELAY)
		// 	.to(subtitle, CONTENT_DURATION, {fillOpacity: 1, onUpdate: moveNode}, "content+="  + CONTENT_DELAY)
		// 	.to(body, CONTENT_DURATION, {fillOpacity: 1, onUpdate: moveNode}, "content"  + CONTENT_DELAY)
		// 	.to(footer, CONTENT_DURATION, {fillOpacity: 1, onUpdate: moveNode}, "content"  + CONTENT_DELAY)
		// 	.stop()

		// this.timeline = new TimelineMax()
		// this.timeline
		// 	.staggerFrom(shapes, HEXES_DURATION, { fillOpacity: 0 }, HEXES_DELAY)
		// 	.call(() => {
		// 		initTimeline.play()
		// 	}, null, null, "text")

		// 	.set({}, {}, "+=2")

		// 	/** 2nd bg **/
		// 	.to(bg1, 0.5, {opacity: 0}, 'renderbg2')
		// 	.to(shapes, 0.5, {opacity: 0}, 'renderbg2')
		// 	.to(bg2, 0.5, {opacity: 1}, 'renderbg2')
		// 	.staggerFrom(shapes2, HEXES_DURATION, { fillOpacity: 0 }, HEXES_DELAY, 'renderbg2')

		// 	.set({}, {}, "+=" + REPEAT_DELAY/2)

		// this.timeline.repeat(0)
		// this.timeline.play()


		/* version text et anims synchrones */
		this.timeline = new TimelineMax()
		this.timeline

			// anim
			.staggerFrom(shapes, HEXES_DURATION, { fillOpacity: 0 }, HEXES_DELAY, "start")

			//text
			.to(preheader, CONTENT_DURATION, {fillOpacity: 1}, "start")

			//text
			.to(title, CONTENT_DURATION, {fillOpacity: 1}, "start+=" + (HEXES_DURATION + HEXES_DELAY))
			.to(subtitle, CONTENT_DURATION, {fillOpacity: 1}, "start+="  + (HEXES_DURATION + HEXES_DELAY))

			.addLabel("renderbg2", "start+=" + (HEXES_DURATION + BG_FADE_DELAY))

			/** 2nd bg **/
			.to(bg1, BG_FADE_DURATION, {opacity: 0}, "renderbg2")
			.to(shapes, BG_FADE_DURATION, {opacity: 0}, "renderbg2")
			.to(bg2, BG_FADE_DURATION, {opacity: 1}, "renderbg2")

			// text
			.to(body, CONTENT_DURATION, {fillOpacity: 1}, "renderbg2")

			// anim
			.staggerFrom(shapes2, HEXES_DURATION, { fillOpacity: 0 }, HEXES_DELAY, "renderbg2")

			// text
			.to(footer, CONTENT_DURATION, {fillOpacity: 1}, "renderbg2+="  + HEXES_DURATION)

			// useful if this.timeline.repeat is set to repeat anim
			.set({}, {}, "+=" + REPEAT_DELAY/2)

		this.timeline.repeat(0)
		this.timeline.play()
	},

	stop(isMovingUp, readyForNextCb, doneStoppingCb) {
	  this.timeline.pause()

	  var shapesRev = Array.prototype.slice.call(shapes,0).reverse()
	  var shapes2Rev = Array.prototype.slice.call(shapes2,0).reverse()

	  var fadeOutTimeline = new TimelineMax()
	  fadeOutTimeline
	  	.to(preheader, CONTENT_DURATION, {fillOpacity: 0}, "fadeOut+=" + 0.5)
	  	.to(title, CONTENT_DURATION, {fillOpacity: 0}, "fadeOut+=" + 0.5)
	  	.to(subtitle, CONTENT_DURATION, {fillOpacity: 0}, "fadeOut+=" + 0.5)
	  	.to(body, CONTENT_DURATION, {fillOpacity: 0}, "fadeOut+=" + 0.5)
	  	.to(footer, CONTENT_DURATION, {fillOpacity: 0}, "fadeOut+=" + 0.5)
	  	.staggerTo(shapesRev, HEXES_DURATION, { fillOpacity: 0 }, HEXES_DELAY, "fadeOut+=" + 0.5)
	  	.staggerTo(shapes2Rev, HEXES_DURATION, { fillOpacity: 0 }, HEXES_DELAY, "fadeOut+=" + 0.5)
	  fadeOutTimeline.play()

	  // start next timeline if a certain progress is acheived
	  var hasCalledReadyForNextCb = false
		fadeOutTimeline.eventCallback('onUpdate', () => {
	  	if(fadeOutTimeline.progress() > START_NEXT_ANIMATION_AT && !hasCalledReadyForNextCb) {
	  	  hasCalledReadyForNextCb = true
		    readyForNextCb()
	  	}
	  })

	  fadeOutTimeline.eventCallback('onComplete', () => {
			if(isMovingUp === true) {
				var slidingTimeline = new TimelineMax
				slidingTimeline.to(this.getDOMNode(), config.SLIDING_DURATION, {top: '-100%'})
			} else if (isMovingUp === false) {
				var slidingTimeline = new TimelineMax
				slidingTimeline.to(this.getDOMNode(), config.SLIDING_DURATION, {top: '100%'})
			}
			this.forceStop(doneStoppingCb)
		})
	}
})
