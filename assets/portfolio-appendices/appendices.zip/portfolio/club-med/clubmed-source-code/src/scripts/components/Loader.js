var React = require('react')

module.exports = React.createClass({

  getStyles() {
    return {
      display: this.props.showLoader ? 'block' : 'none',
      opacity: this.props.showLoader ? 1 : 0
    }
  },

	render() {
    return  <div className="loader" style={this.getStyles()}>
              <img src="../animationAssets/images/loader.gif" key="loader"/>
            </div>
	}
})
