var React = require('react')
	, SVGImage = require('../../components/SVGImage')
	, config = require('../../config')

var Marker = React.createClass({
	componentDidMount : function(){
	  if(typeof this.props.content.link !== 'undefined') {
	    this.updateHref()
	  }
	  this.refs.link.getDOMNode().setAttributeNS(
	    "http://www.w3.org/1999/xlink",
	    "xlink:show",
	    "new"
	  )
	},

	updateHref : function() {
	  this.refs.link.getDOMNode().setAttributeNS(
	    "http://www.w3.org/1999/xlink",
	    "xlink:href",
	    this.props.content.link
	  )
	},

	render() {
		var markerClasses = ['cml-map-marker']
		if(this.props.isDot) {
			markerClasses.push('cml-map-marker-dot')
		}
		if(this.props.isSecondary) {
			markerClasses.push('cml-map-marker-dot-secondary')
		}
		var text = this.props.content.text.map((line, i) => {
			var dy = i == 0 ? 0 : 14
			return <tspan x="0" dy={dy} key={'line'+i}>{line}</tspan>
		})

		var icons = this.props.content.icons.map((icon, i) => {
			var width = (this.props.content['icon'+(i+1)+'width']) ?  this.props.content['icon'+(i+1)+'width'] : 55
			  , height = (this.props.content['icon'+(i+1)+'height']) ?  this.props.content['icon'+(i+1)+'height'] : 55
			  , iconY = (this.props.content.iconY) ?  this.props.content.iconY : 0
			  , iconx = function(initialX, i, padding, isRightAligned) {
			  	if( i == 0 ) { return initialX }
			  	else if( isRightAligned ) { return initialX - (width * i) - padding }
					else { return initialX + (width * i) + padding  }
			  }(this.props.content.iconX, i, 20, (this.props.content.textAnchor !== undefined && this.props.content.textAnchor=="end"))

			return <SVGImage key={"image"+i} className={"cml-map-marker-icon-" + i} xlinkHref={config.assetsServer + icon} width={width} height={height} x={iconx} y={iconY} />
		})

		var dividerEndX = ((this.props.content.textAnchor !== undefined && this.props.content.textAnchor=="end") ? -1 : 1) * (70 * this.props.content.icons.length)
		return (
			<g className={markerClasses.join(' ')} transform={'translate('+this.props.translate.x+','+this.props.translate.y+')'}>
			  <circle r="7" cx="0" cy="0" fill="#666"></circle>
			  <g className="cml-map-marker-content" transform={'translate('+this.props.content.translate.x+','+this.props.content.translate.y+')'}>
			    {icons}
			    <g className="cml-map-marker-details">
  			    <line
  			      x1="0"
  			      y1="65"
  			    	x2={this.props.content.dividerEndX || dividerEndX}
  			    	y2="65"
  			    	stroke="#000"
  			    	strokeWidth="1"/>
  			    <a ref="link">
  			    <text x="0" y="85" textAnchor={ (this.props.content.textAnchor !== undefined) ? this.props.content.textAnchor : ""}>
  			      {text}
  			      <tspan x="-3" dy="15"> </tspan>
  			      <tspan className="readmore" x="0" dy="0">{this.props.viewmore}</tspan>
  			    </text>
  			    </a>
  			  </g>
			  </g>
			 </g>
		)
	}
})

module.exports = Marker
