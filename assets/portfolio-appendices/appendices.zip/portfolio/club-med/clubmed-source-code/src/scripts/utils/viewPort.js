module.exports = function (window) {
  return {
    width: window.innerWidth * 0.9,
    height: window.innerHeight - 138 // header + footer height
  }
}
