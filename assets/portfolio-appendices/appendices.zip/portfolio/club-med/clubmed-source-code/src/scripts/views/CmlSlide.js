/**
| A React mixin for slide views
**/

var React = require('react')
	, SVGImage = require('../components/SVGImage')
	, viewPort = require('../utils/viewPort')

var CmlSlide = {

	contextTypes: {
  	i18n : React.PropTypes.object.isRequired
  },

	getInitialState() {
		return {
			imagesLoaded: false,
			width: 0,
			height: 0
		}
	},

	componentWillLeave(cb) {
		this.props.onLeave((isMovingUp, next) => {
			this.stop(isMovingUp, () => {}, () => {
				next()
				cb()
			})
		})
	},

	init() {
		window.addEventListener('resize', () => {this.resizeSvg()})
		this.resizeSvg()
		if(this.props.onSVGLoad)
			this.props.onSVGLoad(this)
	},

	resizeSvg() {
		this.setState(viewPort(window))
	},

	imagesLoaded: 0,

	getMaskElement(path, classPrefix, i, j) {
		var className = (classPrefix || "cml-shape-") + i
		  , i = (i !== undefined) ? i : ""
		  , j = (j !== undefined) ? j : ""

		if( 'width' in path ) {
      return <rect key={j} className={className} fill="#ffffff" fillOpacity={path.fillOpacity} width={path.width} height={path.height} x={path.x} y={path.y} style={ (path.hasOwnProperty('style'))? path.style : {} }/>
    } else if('r' in path){
      return <circle key={j} className={className} fill="#ffffff" fillOpacity={path.fillOpacity} r={path.r} cx={path.cx} cy={path.cy} style={ (path.hasOwnProperty('style'))? path.style : {} }/>
    } else {
    	return <path key={j} className={className} fill="#ffffff" fillOpacity={path.fillOpacity} d={path.d} style={ (path.hasOwnProperty('style'))? path.style : {} }/>
    }
	},
	getBgMaskElements() {
		return this.images.bg.map((bg, i) => {
			var paths = this.masks.bg.map((path, j) => {
        return this.getMaskElement( path, 'cml-slide-shape-', i, j )
			})
			return (
				<mask key={i} id={'cml-slide-'+this.slideNum+'-bg-mask-'+i}>{paths}</mask>
			)
		})
	},

	getExtraMaskElements() {
		return this.images.extra.map((bg, i) => {
			var paths = this.masks.extra.map((path, j) => {
        return this.getMaskElement( path, 'cml-slide-shadowShape-', i, j )
			})
			return (
				<mask key={i} id={'cml-slide-'+this.slideNum+'-extra-mask-'+i}>
					{paths}
				</mask>
			)
		})
	},

	componentDidMount() {
		if(typeof Image !== 'undefined') {
			this.images.bg.map((image, i) => {
				var shadowImg = new Image
				shadowImg.onload = this.handleImageLoad
				shadowImg.src = image.src
			})
			this.images.extra.map((image, i) => {
				var shadowImg = new Image
				shadowImg.onload = this.handleImageLoad
				shadowImg.src = image.src
			})
		}

		this.text.footer.forEach((footer, i) => {
			var component = this.refs['footerLink'+i]
			if(typeof component !== 'undefined')
				this.applyXlinkHref(component)
		})
	},

	getImage(image, imgType, maskUrl, i) {
		return <SVGImage id={imgType+'-'+i} key={i} xlinkHref={image.src} x={image.x} y={image.y} width={image.width} height={image.height} opacity={1} mask={ maskUrl || "" }/>
	},

	getBgImages() {
		if(!this.state.imagesLoaded)
			return []

		return this.images.bg.map((elem, i) => {
			var maskUrl = 'url(#cml-slide-'+this.slideNum+'-bg-mask-'+i+')';

			if( 'group' in elem ) {
				var groupChildren = elem.group.map((child, j) => {

					if( 'src' in child ) {
						return this.getImage(child, 'bg', maskUrl, i)
					} else {
						return this.getMaskElement( child )
					}
				})

				return  <g className="cml-slide-content-group" mask={maskUrl}>{groupChildren}</g>

			} else {
				return this.getImage(elem, 'bg', maskUrl, i)
			}
		})
	},

	getExtraImages() {
		if(!this.state.imagesLoaded)
			return []

		return this.images.extra.map((image, i) => {
			var maskUrl = 'url(#cml-slide-'+this.slideNum+'-extra-mask-'+i+')';
			return this.getImage(image, 'extra', maskUrl, i)
		})
	},

	handleImageLoad() {
		this.imagesLoaded++
		if(this.isAllImageLoaded()) {
			this.setState({
				imagesLoaded: true
			})
			this.init()
		}
	},


	isAllImageLoaded() {
		return this.imagesLoaded == (this.images.extra.length + this.images.bg.length)
	},

	componentWillMount() {
		this.text = this.context.i18n.slides[this.slideNum-1]
	},

	generateText() {
		var x = this.textOptions.init.x,
				y = this.textOptions.init.y

		if(this.preheaderOptions) {
			var preheaderX = this.preheaderOptions.init.x,
					preheaderY = this.preheaderOptions.init.y
			var preheader = this.text.preheader.map((line, i) => {
				preheaderY += this.preheaderOptions.dy.preheader
				preheaderX = this.preheaderOptions.x(y)
				return <tspan key={'preheader'+i} x={preheaderX} className="cml-slide__preheader" y={preheaderY}>{ line }</tspan>
			})
		} else {
			var preheader = this.text.preheader.map((line, i) => {
				y += this.textOptions.dy.preheader
				x = this.textOptions.x(y)
				return <tspan key={'preheader'+i} x={x} className="cml-slide__preheader" y={y}>{ line }</tspan>
			})
		}

		y += (this.textOptions.dy.hasOwnProperty('titleTopMargin')) ? this.textOptions.dy.titleTopMargin : 10
		var title = this.text.title.map((line, i) => {
			y += this.textOptions.dy.title
			x = this.textOptions.x(y)
			return <tspan key={'title'+i} x={x} className="cml-slide__title" y={y}>{ line }</tspan>
		})
		y += (this.textOptions.dy.hasOwnProperty('subtitleTopMargin')) ? this.textOptions.dy.subtitleTopMargin : 17
		var subtitle = this.text.subtitle.map((line, i) => {
			y += this.textOptions.dy.subtitle
			x = this.textOptions.x(y)
			return <tspan key={'subtitle'+i} x={x} className="cml-slide__subtitle" y={y}>{ line }</tspan>
		})
		y += (this.textOptions.dy.hasOwnProperty('bodyTopMargin')) ? this.textOptions.dy.bodyTopMargin : 15
		var body = this.text.body.map((line, i) => {
			y += this.textOptions.dy.body
			x = this.textOptions.x(y)
			return <tspan key={'body'+i} className="cml-slide__body" x={x} y={y}>{ line }</tspan>
		})
		if(this.text.footer.length > 0) {
			x = this.footerOptions.init.x
			y = this.footerOptions.init.y
			var footer = this.text.footer.map((line, i) => {
				y += this.footerOptions.dy.footer
				x = this.footerOptions.x(y)
				return <tspan key={'footer'+i} className="cml-slide__footer" x={x} y={y}>{ line }</tspan>
			})
		}

		return (
			<text className="cml-slide__content" textAnchor={this.textOptions.textAnchor}>
			  {preheader}
			  {title}
			  {subtitle}
			  {body}
			</text>
		)
	},

	generateFooter() {
		if(this.text.footer.length == 0)
			return null

		var x = this.footerOptions.init.x
		var y = this.footerOptions.init.y
		var footers = this.text.footer.map((footer, i) => {
			var isLink = footer.hasOwnProperty('link') && footer.hasOwnProperty('content')
				, content = footer.content.map((line, j) => {
				y += this.footerOptions.dy.footer
				x = this.footerOptions.x(y)
				return (
					<tspan className="cml-slide__footer" x={x} y={y}>
						{ (isLink && j === (footer.content.length - 1)) ? line + " >" : line }
					</tspan>
				)
			})

			// If is Link
			if(isLink) {
				return (
					<a href={footer.link} ref={"footerLink"+i} className="cml-slide__footerLink" target="_blank">
						{content}
					</a>
				)
			} else {
				return content
			}
		})

		return (
			<text textAnchor={this.footerOptions.textAnchor}>
			  {footers}
			</text>
		)
	},

	applyXlinkHref(component) {
		component.getDOMNode().setAttributeNS(
      "http://www.w3.org/1999/xlink",
      "xlink:href",
      component.props.href
    )
	},

	render() {
		var styles = {
			width: this.state.width,
			height: this.state.height,
			display: 'none'
		}

		return (
			<svg viewBox={this.viewBox} style={styles} preserveAspectRatio="xMidYMid slice" className={'cml-slide cml-slide-'+this.slideNum}>
				<defs key="defs">
					<g>
						{this.getBgMaskElements()}
						{this.getExtraMaskElements()}
					</g>
				</defs>
				<g key="bgs">
					{this.getBgImages()}
				</g>
				<g key="extras">
					{this.getExtraImages()}
				</g>
				<g key="texts">
			  	{this.generateText()}
			  	{this.generateFooter()}
			  </g>
			</svg>
		)
	},


	isActive() {
	  return this.timeline.isActive()
	},

	forceStop(cb) {
	  clearInterval(this.progressInterval)
	  if(this.timeline) {
	    this.timeline.seek(0)
	    this.timeline.pause()
	    this.timeline.kill()
	  }
	  cb()
	}
}

module.exports = CmlSlide
