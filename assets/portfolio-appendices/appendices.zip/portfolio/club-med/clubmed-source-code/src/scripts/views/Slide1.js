var React = require('react')
	, CmlSlide = require('./CmlSlide')
	, config = require('../config')
	, moveNode = require('../utils/moveNode');

if(typeof document !== 'undefined') {
	var gsap = require('gsap')
}

var INTRO_DURATION = 1.1
    , HEXES_DURATION = 0.3
    , HEXES_DELAY = 0.125
    , SHADOW_SLIDE_DURATION = 5
    , SHADOW_SLIDE_DISTANCE = 40
    , SHADOW_DURATION = 1.2
    , SHADOW_DELAY = 0.6
    , CONTENT_DURATION = 3.0
    , CONTENT_DELAY = 0.5
    , CONTENT_SLIDE_DISTANCE = 20
    , REPEAT_DELAY = 8
    , BG_FADE_DURATION = 2
    , SHADOW_FADE_DURATION = 1.5
    , FADE_OUT_SHADOW_DURATION = 1
    , FADE_OUT_BG_DURATION = 2
    , START_NEXT_ANIMATION_AT = 0.75

var shapes, shapes2, shadowShapes, shadowShapes2
	, preheader, title, subtitle, body
	, footer, bg1, bg2, float1, float2

module.exports = React.createClass({
	mixins: [CmlSlide],

	slideNum: 1,
	viewBox: "300 210 1150 1122",

	masks: {
		bg: [
			{fillOpacity:"0.6", d:"M1093,0 L1093,1320 L1082,1320 L1083,0 L1093,0 Z"},
      {fillOpacity:"0.3", d:"M1600,936 L0,936 L0,820 L1600,820 L1600,936 Z"},
      {fillOpacity:"0.9", d:"M1601,851 L1601,819 L0,819 L1,851 L1601,851 Z"},
      {fillOpacity:"0.6", d:"M1093,120 L1093,1320 L836,1320 L836,120 L1093,120 Z"},
      {fillOpacity:"0.2", d:"M1601,1121 L1,1121 L1,286 L1601,286 L1601,1121 Z"},
      {fillOpacity:"0.2", d:"M0,461 L0,909 L1600,910 L1600,460 L0,461 Z"},
      {fillOpacity:"0.4", d:"M1093,120 L1093,1320 L1501,1320 L1501,120 L1093,120 Z"},
      {fillOpacity:"1.0", d:"M1093,601.014 L1093,909 L1600,909 L1600,601 L1093,601 Z"},
      {fillOpacity:"0.4", d:"M1093,601.014 L1093,909 L1600,909 L1600,601 L1093,601 Z"},
      {fillOpacity:"0.8", d:"M1093,601 L1093,909 L1800,909 L1800,601 L1093,601 Z"}
		],
		extra: [
			{fillOpacity:"0.9", d:"M1093,601 L1093,909 L1800,909 L1800,601 L1093,601 Z"},
		  {fillOpacity:"0.4", d:"M1093,120 L1093,1321 L1500,1321 L1500,120 L1093,120 Z"},
      {fillOpacity:"0.4", d:"M1093,120 L1093,1321 L1611,1321 L1611,120 L1093,120 Z"}
		]
	},

	images: {
		bg: [
			{
				src: config.assetsServer + '/animationAssets/images/slide2-hero-a.jpg',
				x: 180,
				y: 398.75,
				width: 1450,
				height: 652.5
			},
			{
				src: config.assetsServer + '/animationAssets/images/slide2-hero-b.jpg',
				x: 90,
				y: 447,
				width: 1440,
				height: 775
			}
		],
		extra: [
			{
				src: config.assetsServer + '/animationAssets/images/slide2-extra-a.png',
				x: 1000,
				y: 450,
				width: 600,
				height: 580
			},
			{
				src: config.assetsServer + '/animationAssets/images/slide2-extra-b.png',
				x: 640,
				y: 350,
				width: 1040,
				height: 729
			}
		]
	},

	textOptions: {
		init: {
			x: 420,
			y: 510,
		},
		dy: {
			preheader: 0,
			title: 45,
			subtitle: 0,
			body: 17
		},
		x: (y) => {
			return 420
		},
		textAnchor: 'start'
	},

	footerOptions: {
		init: {
			x: 880,
			y: 900,
		},
		dy: {
			footer: 13
		},
		x: (y) => {
			return 880
		},
		textAnchor: 'end'
	},

	start(isMovingUp) {
		if(isMovingUp === true) {
			var slidingTimeline = new TimelineMax
			slidingTimeline.from(this.getDOMNode(), config.SLIDING_DURATION, {top: '100%'})
		} else if (isMovingUp === false) {
			var slidingTimeline = new TimelineMax
			slidingTimeline.from(this.getDOMNode(), config.SLIDING_DURATION, {top: '-100%'})
		}

		svg = this.getDOMNode()
		svg.style.display = 'block'

		shapes = svg.querySelectorAll('.cml-slide-shape-0')
		shapes2 = svg.querySelectorAll('.cml-slide-shape-1')
		shadowShapes = svg.querySelectorAll('.cml-slide-shadowShape-0')
		shadowShapes2 = svg.querySelectorAll('.cml-slide-shadowShape-1')
		preheader = svg.querySelectorAll('.cml-slide__preheader')
		title = svg.querySelectorAll('.cml-slide__title')
		subtitle = svg.querySelectorAll('.cml-slide__subtitle')
		body = svg.querySelectorAll('.cml-slide__body')
		footer = svg.querySelectorAll('.cml-slide__footer')
		bg1 = svg.querySelector('#bg-0')
		bg2 = svg.querySelector('#bg-1')
		float1 = svg.querySelector('#extra-0')
		float2 = svg.querySelector('#extra-1')

		bg1.style.opacity = 1
		bg2.style.opacity = 0
		float1.style.opacity = 1
		float2.style.opacity = 0


		/* version text et anims asynchrones */
		// var introTimeline = new TimelineMax;
		// introTimeline
		// 	.to(preheader, CONTENT_DURATION, {fillOpacity: 1, onUpdate: moveNode}, "content")
		// 	.to(title, CONTENT_DURATION, {fillOpacity: 1, onUpdate: moveNode}, "content+=" + CONTENT_DELAY)
		// 	.to(subtitle, CONTENT_DURATION, {fillOpacity: 1, onUpdate: moveNode}, "content+=" + CONTENT_DELAY)
		// 	.to(body, CONTENT_DURATION, {fillOpacity: 1, onUpdate: moveNode}, "content")
		// 	.to(footer, CONTENT_DURATION, {fillOpacity: 1, onUpdate: moveNode}, "content")
		// 	.addLabel('introDone')
		// 	.stop()

		// this.timeline = new TimelineMax
		// this.timeline
		// 	.staggerFrom(shapes, HEXES_DURATION, { fillOpacity: 0 }, HEXES_DELAY)
		// 	.call(() => {
		// 		introTimeline.play()
		// 	}, null, null, "text")

		// 	.addLabel("float1", "text+=1.5")
		// 	.to(float1, SHADOW_SLIDE_DURATION, {attr:{ x: "-=" + SHADOW_SLIDE_DISTANCE}}, "float1")
		// 	.staggerFrom(shadowShapes, SHADOW_DURATION, { fillOpacity: 0 }, SHADOW_DELAY, "float1")

		// 	.addLabel("transition1")

		// 	/** Change Bg **/
		// 	.staggerTo(shadowShapes, SHADOW_DURATION, {opacity: 0}, 0.15, "transition1")
		// 	.to(float1, 0.5, {opacity: 0} , "transition1")
		// 	.staggerTo(shapes, HEXES_DURATION, {opacity: 0}, 0.15, "transition1+="+ FADE_OUT_SHADOW_DURATION)
		// 	.to(bg1, 0.5, {opacity: 0} , "transition1+="+ FADE_OUT_SHADOW_DURATION)
		// 	.set(bg2, {opacity: 1} , "transition1+="+ FADE_OUT_SHADOW_DURATION)
		// 	.staggerFrom(shapes2, HEXES_DURATION, {fillOpacity: 0}, HEXES_DELAY, "transition1+="+FADE_OUT_SHADOW_DURATION)

		// 	.addLabel("bg2")

		// 	/** Change extra **/
		// 	.set(float2, {opacity: 1}, "bg2+=" + (SHADOW_FADE_DURATION + 0.5))
		// 	.staggerFrom(shadowShapes2, SHADOW_DURATION, {fillOpacity: 0}, SHADOW_DELAY, "bg2+=" + (SHADOW_FADE_DURATION + 0.5))
		// 	.set({}, {}, "+=" + REPEAT_DELAY/2)


		/* version text et anims synchrones */
		this.timeline = new TimelineMax
		this.timeline

			// anim
			.staggerFrom(shapes, HEXES_DURATION, { fillOpacity: 0 }, HEXES_DELAY, "start")

			// text
			.to(preheader, CONTENT_DURATION, {fillOpacity: 1}, "start")

			// anim
			.to(float1, SHADOW_SLIDE_DURATION, {attr:{ x: "-=" + SHADOW_SLIDE_DISTANCE}}, "float1")
			.staggerFrom(shadowShapes, SHADOW_DURATION, { fillOpacity: 0 }, SHADOW_DELAY, "float1")

			// text
			.to(title, CONTENT_DURATION, {fillOpacity: 1}, "float1")
			.to(subtitle, CONTENT_DURATION, {fillOpacity: 1}, "float1")

			/** Change Bg **/
			.staggerTo(shadowShapes, SHADOW_DURATION, {opacity: 0}, 0.15, "transition1")
			.to(float1, 0.5, {opacity: 0} , "transition1")
			.staggerTo(shapes, HEXES_DURATION, {opacity: 0}, 0.15, "transition1+="+ FADE_OUT_SHADOW_DURATION)
			.to(bg1, 0.5, {opacity: 0} , "transition1+="+ FADE_OUT_SHADOW_DURATION)
			.set(bg2, {opacity: 1} , "transition1+="+ FADE_OUT_SHADOW_DURATION)
			.staggerFrom(shapes2, HEXES_DURATION, {fillOpacity: 0}, HEXES_DELAY, "transition1+="+FADE_OUT_SHADOW_DURATION)
			.addLabel("bg2", "transition1+=" + (FADE_OUT_SHADOW_DURATION + SHADOW_DURATION))

			// text
			.to(body, CONTENT_DURATION, {fillOpacity: 1}, "transition1+="+ FADE_OUT_SHADOW_DURATION)

			/** Change extra **/
			.set(float2, {opacity: 1}, "bg2+=" + (SHADOW_FADE_DURATION + 0.5))
			.staggerFrom(shadowShapes2, SHADOW_DURATION, {fillOpacity: 0}, SHADOW_DELAY, "bg2+=" + (SHADOW_FADE_DURATION + 0.5))

			// text
			.to(footer, CONTENT_DURATION, {fillOpacity: 1}, "bg2+=" + (SHADOW_FADE_DURATION + 0.5))

			// useful if this.timeline.repeat is set to repeat anim
			.set({}, {}, "+=" + REPEAT_DELAY/2)

		// uncomment to log text appearance time
		// 	.addCallback(() => {console.log('preheader',timeline.time())},"start")
		// 	.addCallback(() => {console.log('title',timeline.time())},"float1")
		// 	.addCallback(() => {console.log('body',timeline.time())},"transition1+="+ FADE_OUT_SHADOW_DURATION)
		// 	.addCallback(() => {console.log('footer',timeline.time())},"bg2+=" + (SHADOW_FADE_DURATION + 0.5))
		// var timeline = this.timeline

		this.timeline.repeat(0)
	},

	stop(isMovingUp, readyForNextCb, doneStoppingCb) {
		this.timeline.pause()

		var shadowShapesRev = Array.prototype.slice.call(shadowShapes,0).reverse()
		var shadowShapes2Rev = Array.prototype.slice.call(shadowShapes2,0).reverse()
		var shapesRev = Array.prototype.slice.call(shapes,0).reverse()
		var shapes2Rev = Array.prototype.slice.call(shapes2,0).reverse()

		var fadeOutTimeline = new TimelineMax()
		fadeOutTimeline
			.staggerTo(shadowShapesRev, HEXES_DURATION, { fillOpacity: 0 }, HEXES_DELAY, "startedFadingOut")
			.staggerTo(shadowShapes2Rev, HEXES_DURATION, { fillOpacity: 0 }, HEXES_DELAY, "startedFadingOut")
			.to(preheader, CONTENT_DURATION, {fillOpacity: 0}, "startedFadingOut+=" + HEXES_DURATION/2)
			.to(title, CONTENT_DURATION, {fillOpacity: 0}, "startedFadingOut+=" + HEXES_DURATION/2)
			.to(subtitle, CONTENT_DURATION, {fillOpacity: 0}, "startedFadingOut+=" + HEXES_DURATION/2)
			.to(body, CONTENT_DURATION, {fillOpacity: 0}, "startedFadingOut+=" + HEXES_DURATION/2)
			.to(footer, CONTENT_DURATION, {fillOpacity: 0}, "startedFadingOut+=" + HEXES_DURATION/2)
			.staggerTo(shapesRev, HEXES_DURATION, { fillOpacity: 0 }, HEXES_DELAY, "startedFadingOut+=" + HEXES_DURATION/2)
			.staggerTo(shapes2Rev, HEXES_DURATION, { fillOpacity: 0 }, HEXES_DELAY, "startedFadingOut+=" + HEXES_DURATION/2)
		fadeOutTimeline.play()

		// start next timeline if a certain progress is acheived
		var hasCalledReadyForNextCb = false
		fadeOutTimeline.eventCallback('onUpdate', () => {
		  if(fadeOutTimeline.progress() > START_NEXT_ANIMATION_AT && !hasCalledReadyForNextCb) {
		    hasCalledReadyForNextCb = true
		    readyForNextCb()
		  }
		})
		fadeOutTimeline.eventCallback('onComplete', () => {
			if(isMovingUp === true) {
				var slidingTimeline = new TimelineMax
				slidingTimeline.to(this.getDOMNode(), config.SLIDING_DURATION, {top: '-100%'})
			} else if (isMovingUp === false) {
				var slidingTimeline = new TimelineMax
				slidingTimeline.to(this.getDOMNode(), config.SLIDING_DURATION, {top: '100%'})
			}
			this.forceStop(doneStoppingCb)
		})
	}
})
