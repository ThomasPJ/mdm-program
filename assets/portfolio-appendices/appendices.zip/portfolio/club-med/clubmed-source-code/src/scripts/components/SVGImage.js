var React = require('react')

var SVGImage = React.createFactory("image")

var Image = React.createClass({

  propTypes : {
    x : React.PropTypes.number.isRequired,
    y : React.PropTypes.number.isRequired,
    width : React.PropTypes.number.isRequired,
    height : React.PropTypes.number.isRequired,
    xlinkHref : React.PropTypes.string.isRequired
  },

  componentDidMount : function(){
    if(typeof this.props.xlinkHref !== 'undefined') {
      this.updateHref()  
    }
    if(typeof this.props.mask !== 'undefined') {
      this.updateMask()
    }
  },

  componentDidUpdate : function(nextProps) {
    if(this.props.xlinkHref !== nextProps.xlinkHref) {
      this.updateHref()
    }
    if(this.props.mask !== nextProps.mask) {
      this.updateMask()
    }
  },

  updateHref : function() {
    this.refs.image.getDOMNode().setAttributeNS(
      "http://www.w3.org/1999/xlink",
      "xlink:href",
      this.props.xlinkHref
    )
  },

  updateMask : function() {
    this.refs.image.getDOMNode().setAttribute(
      "mask",
      this.props.mask
    )
  },

  render: function() {
    return (
      <g>
        {SVGImage(React.__spread({}, this.props, {ref:"image"}))}
      </g>
    )
  }
})

module.exports = Image
