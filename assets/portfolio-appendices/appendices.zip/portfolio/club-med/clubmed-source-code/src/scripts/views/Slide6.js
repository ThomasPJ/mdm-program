var React = require('react')
	, SVGImage = require('../components/SVGImage')
	, Marker = require('./map/Marker')
	, config = require('../config')
	, moveNode = require('../utils/moveNode')
	, viewPort = require('../utils/viewPort')

if(typeof document !== 'undefined') {
	var gsap = require('gsap')
}

var INTRO_DURATION = 0.5
    , HEXES_DURATION = 0.6
    , HEXES_DELAY = 0.3
    , SHADOW_DURATION = 0.7
    , CONTENT_DURATION = 1.5
    , CONTENT_SLIDE_DISTANCE = 20
    , REPEAT_DELAY = 8

var Slide6 = React.createClass({
	mixins: [],
	slideNum: 6,
	contextTypes: {
  	i18n : React.PropTypes.object.isRequired
  },

  getInitialState() {
    return {}
  },

  initResize() {
    window.addEventListener('resize', () => {this.resizeSVG()})
    this.resizeSVG()
  },

  resizeSVG() {
    this.setState(viewPort(window))
  },

	componentWillLeave(cb) {
		this.props.onLeave((isMovingUp, next) => {
			next()
			var timeline = new TimelineMax
			timeline.to(this.getDOMNode(), config.SLIDING_DURATION, {top: '100%'})
				.call(cb)
		})
	},

	viewBox: "0 0 1600 1030",

	componentDidMount() {
		setTimeout(() => {
			this.props.onSVGLoad(this)
		}, 1)

		this.initResize()
	},

	start(isMovingUp) {
		if(isMovingUp === true) {
			var slidingTimeline = new TimelineMax
			slidingTimeline.from(this.getDOMNode(), config.SLIDING_DURATION, {top: '100%'})
		} else if (isMovingUp === false) {
			var slidingTimeline = new TimelineMax
			slidingTimeline.from(this.getDOMNode(), config.SLIDING_DURATION, {top: '-100%'})
		}
		var svg = this.getDOMNode()
		svg.style.display = 'block'

		var mapSelector = svg.querySelectorAll('.cml-map-image')
			, markersWrapperSelector = svg.querySelectorAll('.cml-map-markers')

		var tml = new TimelineMax();
		tml
			.from(mapSelector, INTRO_DURATION, {opacity: 0}, INTRO_DURATION)
			.from(markersWrapperSelector, HEXES_DURATION, { opacity: 0, scale: 1.2 }, HEXES_DELAY)

		Array.prototype.forEach.call(document.querySelectorAll('.cml-map-marker'), function (marker) {

			var markerTrigger = ( " "+ marker.getAttribute("class") +" ").indexOf( " cml-map-marker-dot ") > -1
				? marker.querySelector('circle')
				: marker.querySelector('.cml-map-marker-icon-0')
			var markerContent = ( " "+ marker.getAttribute("class") +" ").indexOf( " cml-map-marker-dot ") > -1
				? marker.querySelector('.cml-map-marker-content')
				: marker.querySelector('.cml-map-marker-details')

			markerContent.style.display = 'none'

			var isInTrigger = false
				, isInContent = false
				, fadeTimeout
				, fadeTimeoutTimer = 200

			function fadeIn() {
				markerContent.style.display = 'block'
				TweenMax.to( markerContent, 0.3, {opacity: 1}, 0.1 )
				if(fadeTimeoutTimer) {
					clearTimeout(fadeTimeout)
				}
			}

			function fadeOut() {
				clearTimeout(fadeTimeout)
				setTimeout(() => {
					if(!isInTrigger && !isInContent) {
						fadeTimeout = setTimeout(() => {
							TweenMax.to(markerContent, 0.3, {opacity: 0, onComplete: () => {
								markerContent.style.display = 'none'
							}}).delay(0.3)
						}, fadeTimeoutTimer)
					}
				}, 200)

			}

			// markerContent.style.display = 'none'

		  markerTrigger.addEventListener('mouseover', () => {
		  	isInTrigger = true
		  	fadeIn()
		  }, false)
			markerTrigger.addEventListener('mouseout', () => {
				isInTrigger = false
				fadeOut()
			}, false)
			markerContent.addEventListener('mouseover', () => {
				isInContent = true
			}, false)
			markerContent.addEventListener('mouseout', () => {
				isInContent = false
				fadeOut()
			}, false)

		})
	},

	componentWillMount() {
		this.markers = this.context.i18n.slides[this.slideNum-1].markers
		this.viewmore = this.context.i18n.slides[this.slideNum-1].viewmore
	},

	getMarkers() {
		return this.markers.map((marker, i) => {
			marker.viewmore = this.viewmore
			return <Marker key={"marker"+i} {...marker} />
		})
	},

	render() {
    var SVGStyles = {
      width: this.state.width,
      height: this.state.height
    }

		return (
			<svg id={'cml-slide' + this.slideNum} viewBox={this.viewBox} preserveAspectRatio="xMidYMid slice" style={SVGStyles} >
				<SVGImage key="image" className="cml-map-image" xlinkHref={config.assetsServer + '/animationAssets/images/slide8-map.jpg'} x={0} y={0} width={1600} height={1030} />
				<g className="cml-map-markers" key="markers">
					{this.getMarkers()}
				</g>
			</svg>
		)
	},

	stop(isMovingUp, readyForNextCb, doneStoppingCb) {
		readyForNextCb()
		doneStoppingCb()
	}
})

module.exports = Slide6
