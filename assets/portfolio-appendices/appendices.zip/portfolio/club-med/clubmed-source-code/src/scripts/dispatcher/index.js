var _ = require("underscore")
var Backbone = require("backbone")

/**
 * Dispatcher is an object that can be used by all the app,
 * it implements events, throught the following methods :
 *   - `on(type, callback, context)`
 *   - `once(type, callback, context)`
 *   - `off(type, callback, context)`
 *   - `trigger(type)`
 *
 * e.g.
 *   var Dispatcher = require("dispatcher")
 *
 *   var OverlayView = Backbone.View.extend({
 *      initialize() {
 *        _.bindAll(this)
 *        this.listenTo(Dispatcher, "Modal:open", this.show)
 *      }
 *      …
 *   })
 *
 */
var Dispatcher = _.extend({}, Backbone.Events)

module.exports = Dispatcher
