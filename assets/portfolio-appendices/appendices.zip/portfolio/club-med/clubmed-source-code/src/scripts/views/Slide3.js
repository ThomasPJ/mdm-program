var React = require('react')
	, CmlSlide = require('./CmlSlide')
	, config = require('../config')
	, moveNode = require('../utils/moveNode');

if(typeof document !== 'undefined') {
	var gsap = require('gsap')
}

var INTRO_DURATION = 1.1
    , HEXES_DURATION = 0.8
    , HEXES_DELAY = 0.125
    , SHADOW_DURATION = 0.2
    , SHADOW_DELAY = 0.3
    , CONTENT_DURATION = 3.0
    , CONTENT_DELAY = 0.5
    , CONTENT_SLIDE_DISTANCE = 20
    , REPEAT_DELAY = 8
    , BG_FADE_DELAY = 2
    , BG_FADE_DURATION = 0.5
    , SHADOW_FADE_DURATION = 1.5
    , FADE_OUT_SHADOW_DURATION = 1
    , FADE_OUT_BG_DURATION = 2
    , START_NEXT_ANIMATION_AT = 0.75

var shapes, shapes2, shadowShapes
	, preheader, title, subtitle
	, body, footer, bg1, bg2
	, float1

module.exports = React.createClass({
	mixins: [CmlSlide],

	slideNum: 3,
	viewBox: "50 70 1454 900",
	masks: {
		bg: [
      {fillOpacity:"0.8", x:"927", y:"487", width:"125", height:"129"},
      {fillOpacity:"0.9", x:"1055", y:"616", width:"77", height:"78"},
      {fillOpacity:"0.8", x:"1055", y:"584", width:"29", height:"30"},
      {fillOpacity:"0.8", x:"849", y:"619", width:"202", height:"205"},
      {fillOpacity:"0.8", x:"1089", y:"566", width:"47", height:"49"},
      {fillOpacity:"0.2", x:"932", y:"622", width:"329", height:"333"},
      {fillOpacity:"0.3", d:"M100,94 L929,99 L929,462 L1406,462 L1403,970 L95,962 Z"},
      {fillOpacity:"0.3", d:"M39,35 L930,29 L930,462 L1448,462 L1453,971 L48,972 Z"},
      {fillOpacity:"0.4", d:"M0,6 L924,0 L928,970 L3,972 Z"},
      {fillOpacity:"0.6", d:"M57,93 L924,93 L926,961 L57,961 Z"}
		],
		extra: [
      {fillOpacity:"0.6", x:"930", y:"619", width:"331", height:"335"},
      {fillOpacity:"0.9", x:"1055", y:"584", width:"29", height:"30"},
      {fillOpacity:"0.6", x:"1089", y:"566", width:"47", height:"49"},
      {fillOpacity:"0.8", x:"1055", y:"616", width:"77", height:"78"},
      {fillOpacity:"1.0", x:"849", y:"619", width:"202", height:"205"}
		]
	},

	images: {
		bg: [
			{
			  src: config.assetsServer + '/animationAssets/images/slide4-hero-a.jpg',
			  x: -225,
			  y: -5,
			  width: 1800,
			  height: 1133
			},
			{
			  src: config.assetsServer + '/animationAssets/images/slide4-hero-b.jpg',
			  x: -225,
			  y: -5,
			  width: 1800,
			  height: 1133
			}
		],
		extra: [
			{
			  src: config.assetsServer + '/animationAssets/images/slide4-extra-a.png',
			  x: 710,
			  y: 400,
			  width: 756,
			  height: 609
			}
		]
	},

	preheaderOptions: {
		init: {
			x: 900,
			y: 242,
		},
		dy: {
			preheader: 17,
			title: 28,
			subtitle: 19,
			body: 25
		},
		x: (y) => {
			return 900
		},
		textAnchor: 'end'
	},

	textOptions: {
		init: {
			x: 950,
			y: 170,
		},
		dy: {
			preheader: 17,
			title: 28,
			subtitle: 19,
			body: 25
		},
		x: (y) => {
			return 950
		},
		textAnchor: 'start'
	},

	footerOptions: {
		init: {
			x: 950,
			y: 400,
		},
		dy: {
			footer: 24
		},
		x: (y) => {
			return 950
		},
		textAnchor: 'start'
	},

	start(isMovingUp) {
		if(isMovingUp === true) {
			var slidingTimeline = new TimelineMax
			slidingTimeline.from(this.getDOMNode(), config.SLIDING_DURATION, {top: '100%'})
		} else if (isMovingUp === false) {
			var slidingTimeline = new TimelineMax
			slidingTimeline.from(this.getDOMNode(), config.SLIDING_DURATION, {top: '-100%'})
		}
		var svg = this.getDOMNode()
		svg.style.display = 'block'

		shapes = svg.querySelectorAll('.cml-slide-shape-0')
		shapes2 = svg.querySelectorAll('.cml-slide-shape-1')
		shadowShapes = svg.querySelectorAll('.cml-slide-shadowShape-0')
		preheader = svg.querySelectorAll('.cml-slide__preheader')
		title = svg.querySelectorAll('.cml-slide__title')
		subtitle = svg.querySelectorAll('.cml-slide__subtitle')
		body = svg.querySelectorAll('.cml-slide__body')
		footer = svg.querySelectorAll('.cml-slide__footer')
		bg1 = svg.querySelector('#bg-0')
		bg2 = svg.querySelector('#bg-1')
		float1 = svg.querySelector('#extra-0')

		bg2.style.opacity = 0
		float1.style.opacity = 0


		/* version text et anims asynchrones */
		// var initTimeline = new TimelineMax
		// initTimeline
		// 	.to(preheader, CONTENT_DURATION, {fillOpacity: 1, onUpdate: moveNode}, "content")
		// 	.to(title, CONTENT_DURATION, {fillOpacity: 1, onUpdate: moveNode}, "content+=" + CONTENT_DELAY)
		// 	.to(subtitle, CONTENT_DURATION, {fillOpacity: 1, onUpdate: moveNode}, "content+=" + CONTENT_DELAY)
		// 	.to(body, CONTENT_DURATION, {fillOpacity: 1, onUpdate: moveNode}, "content+=" + CONTENT_DELAY)
		// 	.to(footer, CONTENT_DURATION, {fillOpacity: 1, onUpdate: moveNode}, "content+=" + CONTENT_DELAY)
		// 	.stop()

		// this.timeline = new TimelineMax()
		// this.timeline
		// 	.staggerFrom(shapes, HEXES_DURATION, { fillOpacity: 0 }, HEXES_DELAY)
		// 	.call(() => {
		// 		initTimeline.play()
		// 	}, null, null, "text")

		// 	.set({}, {}, "+=2")

		// 	/** 2nd bg **/
		// 	.to(bg1, 0.5, {opacity: 0}, 'renderbg2')
		// 	.set(bg2, {opacity: 1}, 'renderbg2')
		// 	.staggerFrom(shapes2, HEXES_DURATION, { fillOpacity: 0 }, HEXES_DELAY, 'renderbg2')

		// 	/** Render first extra **/
		// 	.addLabel("float1")
		// 	.set(float1, {opacity: 1}, 'float1')
		// 	.staggerFrom(shadowShapes, SHADOW_DURATION, { fillOpacity: 0 }, SHADOW_DELAY, 'float1')


		// 	.set({}, {}, "+=" + REPEAT_DELAY/2)


		/* version text et anims synchrones */
		this.timeline = new TimelineMax()
		this.timeline

			// anim
			.staggerFrom(shapes, HEXES_DURATION, { fillOpacity: 0 }, HEXES_DELAY, "start")

			// text
			.to(preheader, CONTENT_DURATION, {fillOpacity: 1}, "start")

			// text
			.to(title, CONTENT_DURATION, {fillOpacity: 1}, "start+=" + (HEXES_DURATION + HEXES_DELAY))
			.to(subtitle, CONTENT_DURATION, {fillOpacity: 1}, "start+=" + (HEXES_DURATION + HEXES_DELAY))

			.addLabel("renderbg2", "start+=" + (HEXES_DURATION + BG_FADE_DELAY))


			/** 2nd bg **/
			.to(bg1, BG_FADE_DURATION, {opacity: 0}, "renderbg2")
			.staggerFrom(shapes2, HEXES_DURATION, { fillOpacity: 0 }, HEXES_DELAY, "renderbg2")
			.set(bg2, {opacity: 1}, "renderbg2")

			// text
			.to(body, CONTENT_DURATION, {fillOpacity: 1}, "renderbg2")

			/** Render first extra **/
			.addLabel("float1")
			.set(float1, {opacity: 1}, "float1")

			// anim
			.staggerFrom(shadowShapes, SHADOW_DURATION, { fillOpacity: 0 }, SHADOW_DELAY, "float1")

			// text
			.to(footer, CONTENT_DURATION, {fillOpacity: 1}, "float1")

			// useful if this.timeline.repeat is set to repeat anim
			.set({}, {}, "+=" + REPEAT_DELAY/2)

		this.timeline.repeat(0)
	},

	stop(isMovingUp, readyForNextCb, doneStoppingCb) {
	  this.timeline.pause()

	  var shadowShapesRev = Array.prototype.slice.call(shadowShapes,0).reverse()
	  var shapesRev = Array.prototype.slice.call(shapes,0).reverse()
	  var shapes2Rev = Array.prototype.slice.call(shapes2,0).reverse()

	  var fadeOutTimeline = new TimelineMax()
	  fadeOutTimeline
	  	.staggerTo(shadowShapesRev, HEXES_DURATION, { fillOpacity: 0 }, HEXES_DELAY, "fadeOut")
	  	.to(preheader, CONTENT_DURATION, {fillOpacity: 0}, "fadeOut+="+1)
	  	.to(title, CONTENT_DURATION, {fillOpacity: 0}, "fadeOut+="+1)
	  	.to(subtitle, CONTENT_DURATION, {fillOpacity: 0}, "fadeOut+="+1)
	  	.to(body, CONTENT_DURATION, {fillOpacity: 0}, "fadeOut+="+1)
	  	.to(footer, CONTENT_DURATION, {fillOpacity: 0}, "fadeOut+="+1)
	  	.staggerTo(shapesRev, HEXES_DURATION, { fillOpacity: 0 }, HEXES_DELAY, "fadeOut+="+1)
	  	.staggerTo(shapes2Rev, HEXES_DURATION, { fillOpacity: 0 }, HEXES_DELAY, "fadeOut+="+1)
	  fadeOutTimeline.play()

	  // start next timeline if a certain progress is acheived
	  var hasCalledReadyForNextCb = false
		fadeOutTimeline.eventCallback('onUpdate', () => {
	    if(fadeOutTimeline.progress() > START_NEXT_ANIMATION_AT && !hasCalledReadyForNextCb) {
	      hasCalledReadyForNextCb = true
		    readyForNextCb()
	    }
	  })

	  fadeOutTimeline.eventCallback('onComplete', () => {
			if(isMovingUp === true) {
				var slidingTimeline = new TimelineMax
				slidingTimeline.to(this.getDOMNode(), config.SLIDING_DURATION, {top: '-100%'})
			} else if (isMovingUp === false) {
				var slidingTimeline = new TimelineMax
				slidingTimeline.to(this.getDOMNode(), config.SLIDING_DURATION, {top: '100%'})
			}
			this.forceStop(doneStoppingCb)
		})
	}
})
