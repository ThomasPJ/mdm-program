var React = require('react')
  , domReady = require("bloody-domready")
  , Router = require('react-router')
  , App = require('./App')
  , routes = require('./routes')
  , config = require('./config')

require('whatwg-fetch')

var lang = LANG
var langRoute = routes(lang)

domReady(function() {
  Router.run(langRoute, Router.HistoryLocation, (Handler, state) => {    
    fetch(`${config.assetsServer}/animationAssets/lang/${lang}.json`, {mode: 'cors', headers: {'Access-Control-Allow-Origin': '*'}})
      .then((result) => {
        return result.json()
      })
      .then((result) => {
        React.render(<Handler i18n={result} lang={lang} langRoute={langRoute} />, document);
      })
  });
})
