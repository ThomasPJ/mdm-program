var React = require('react')
var Router = require('react-router');
var DefaultRoute = Router.DefaultRoute;
var Link = Router.Link;
var Route = Router.Route;
var RouteHandler = Router.RouteHandler;

var App = require('./App')
  , Slide1 = require('./views/Slide1.js')
  , Slide2 = require('./views/Slide2.js')
  , Slide3 = require('./views/Slide3.js')
  , Slide4 = require('./views/Slide4.js')
  , Slide5 = require('./views/Slide5.js')
  , Slide6 = require('./views/Slide6.js')
  , Home = require('./views/Home.js')

var routes = function(lang) {
  var prefixPath = (process.env.NODE_ENV === 'development' ? '' : '/clubmed-luxe') + '/' + lang + '/'
  return (
    <Route name="app" path={prefixPath} handler={App}>
      <Route name="slide0" path="home.html" handler={Home} addHandlerKey={true} />
      <Route name="slide1" path="1.html" handler={Slide1} addHandlerKey={true} />
      <Route name="slide2" path="2.html" handler={Slide2} addHandlerKey={true}  />
      <Route name="slide3" path="3.html" handler={Slide3} addHandlerKey={true}  />
      <Route name="slide4" path="4.html" handler={Slide4} addHandlerKey={true}  />
      <Route name="slide5" path="5.html" handler={Slide5} addHandlerKey={true}  />
      <Route name="slide6" path="6.html" handler={Slide6} addHandlerKey={true}  />
    </Route>
  )
}

/*
|----------------------------------------
| CMS Routes
| Uncomment on production server
|----------------------------------------
*/
// var routes = function(lang) {
//   switch(lang) {
//     case 'fr':
//       return (
//         <Route name="app" path="/cm/" handler={App}>
//           <Route name="home" path="home.html" handler={Home} addHandlerKey={true} />
//           <Route name="slide1" path="test-du-nouveau-template-webagency-fluide_p-133-l-FR-pa-PageLuxe1-ac-di.html" handler={Slide1} addHandlerKey={true} />
//           <Route name="slide2" path="test-du-nouveau-template-webagency-fluide_p-133-l-FR-pa-PageLuxe2-ac-di.html" handler={Slide2} addHandlerKey={true}  />
//           <Route name="slide3" path="test-du-nouveau-template-webagency-fluide_p-133-l-FR-pa-PageLuxe3-ac-di.html" handler={Slide3} addHandlerKey={true}  />
//           <Route name="slide4" path="test-du-nouveau-template-webagency-fluide_p-133-l-FR-pa-PageLuxe4-ac-di.html" handler={Slide4} addHandlerKey={true}  />
//           <Route name="slide5" path="test-du-nouveau-template-webagency-fluide_p-133-l-FR-pa-PageLuxe5-ac-di.html" handler={Slide5} addHandlerKey={true}  />
//           <Route name="slide6" path="test-du-nouveau-template-webagency-fluide_p-133-l-FR-pa-PageLuxe6-ac-di.html" handler={Slide6} addHandlerKey={true}  />
//           <Route name="slide7" path="test-du-nouveau-template-webagency-fluide_p-133-l-FR-pa-PageLuxe7-ac-di.html" handler={Slide7} addHandlerKey={true}  />
//           <Route name="slide8" path="test-du-nouveau-template-webagency-fluide_p-133-l-FR-pa-PageLuxe8-ac-di.html" handler={Slide8} addHandlerKey={true}  />
//           <Route name="slide1-nocache" path="test-du-nouveau-template-webagency-fluide_p-133-l-FR-nocache-:random-pa-PageLuxe1-ac-di.html" handler={Slide1} addHandlerKey={true} />
//           <Route name="slide2-nocache" path="test-du-nouveau-template-webagency-fluide_p-133-l-FR-nocache-:random-pa-PageLuxe2-ac-di.html" handler={Slide2} addHandlerKey={true} />
//           <Route name="slide3-nocache" path="test-du-nouveau-template-webagency-fluide_p-133-l-FR-nocache-:random-pa-PageLuxe3-ac-di.html" handler={Slide3} addHandlerKey={true} />
//           <Route name="slide4-nocache" path="test-du-nouveau-template-webagency-fluide_p-133-l-FR-nocache-:random-pa-PageLuxe4-ac-di.html" handler={Slide4} addHandlerKey={true} />
//           <Route name="slide5-nocache" path="test-du-nouveau-template-webagency-fluide_p-133-l-FR-nocache-:random-pa-PageLuxe5-ac-di.html" handler={Slide5} addHandlerKey={true} />
//           <Route name="slide6-nocache" path="test-du-nouveau-template-webagency-fluide_p-133-l-FR-nocache-:random-pa-PageLuxe6-ac-di.html" handler={Slide6} addHandlerKey={true} />
//           <Route name="slide7-nocache" path="test-du-nouveau-template-webagency-fluide_p-133-l-FR-nocache-:random-pa-PageLuxe7-ac-di.html" handler={Slide7} addHandlerKey={true} />
//           <Route name="slide8-nocache" path="test-du-nouveau-template-webagency-fluide_p-133-l-FR-nocache-:random-pa-PageLuxe8-ac-di.html" handler={Slide8} addHandlerKey={true} />
//         </Route>
//       )
//     case 'en':
//       return (
//         <Route name="app" path="/cm/" handler={App}>
//           <Route name="slide1" path="new-test-template-webagency-fluide_p-134-l-FR-pa-PageLuxe1-ac-di.html" handler={Slide1} addHandlerKey={true} />
//           <Route name="slide2" path="new-test-template-webagency-fluide_p-134-l-FR-pa-PageLuxe2-ac-di.html" handler={Slide2} addHandlerKey={true}  />
//           <Route name="slide3" path="new-test-template-webagency-fluide_p-134-l-FR-pa-PageLuxe3-ac-di.html" handler={Slide3} addHandlerKey={true}  />
//           <Route name="slide4" path="new-test-template-webagency-fluide_p-134-l-FR-pa-PageLuxe4-ac-di.html" handler={Slide4} addHandlerKey={true}  />
//           <Route name="slide5" path="new-test-template-webagency-fluide_p-134-l-FR-pa-PageLuxe5-ac-di.html" handler={Slide5} addHandlerKey={true}  />
//           <Route name="slide6" path="new-test-template-webagency-fluide_p-134-l-FR-pa-PageLuxe6-ac-di.html" handler={Slide6} addHandlerKey={true}  />
//           <Route name="slide7" path="new-test-template-webagency-fluide_p-134-l-FR-pa-PageLuxe7-ac-di.html" handler={Slide7} addHandlerKey={true}  />
//           <Route name="slide8" path="new-test-template-webagency-fluide_p-134-l-FR-pa-PageLuxe8-ac-di.html" handler={Slide8} addHandlerKey={true}  />
//         </Route>
//       )
//   }
// }
  

module.exports = routes;