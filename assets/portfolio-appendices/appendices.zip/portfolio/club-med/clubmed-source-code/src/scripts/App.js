var React = require('react/addons')
  , CmlSlide = require('./views/CmlSlide')
  , MiddleNav = require('./views/MiddleNav')
  , Loader = require('./components/Loader.js')
  , Router = require('react-router')
  , { Route, RouteHandler, Link } = Router
  , TransitionGroup = React.addons.TransitionGroup
  , config = require('./config')
  , viewPort = require('./utils/viewPort')

var TOTAL_SLIDES = 6

function TransitionHandlerFactory(Component) {
  return React.createClass({
    componentWillLeave(cb) {
      var component = this.component
      if(component.componentWillLeave) {
        component.componentWillLeave(cb)
      }
    },

    shouldComponentUpdate() {
    	// Prevent RouteHandler from overwritting the slide
    	return false
    },

    render() {
      return (
        <Component ref="handler" key={this.props.keyName} {...this.props}/>
      )
    },

    componentDidMount() {
    	this.component = this.refs.handler._renderedComponent
    }
  })
}

var TransitionRouteHandler = TransitionHandlerFactory(RouteHandler)

var App = React.createClass({
	mixins: [ Router.State, Router.Navigation ],

	getInitialState() {
		return {
			isLoading: true,
			navigationAllowed: false,
			currentSlideNum: 0,
			leavingSlideNum: 0
		}
	},

	handleSlideLoad(slide) {

	  if(typeof this.leavingSlideCb !== 'undefined') {
	  	var isMovingUp = slide.slideNum > this.state.leavingSlideNum
	  	this.leavingSlideCb(isMovingUp, () => {
	  		slide.start(isMovingUp)
	  		this.setState({
	  			isLoading: false,
	  			currentSlideNum: slide.slideNum,
	  			navigationAllowed: true
	  		})
	  	})
	  } else {
	  	slide.start()
	  	this.setState({
	  		isLoading: false,
	  		currentSlideNum: slide.slideNum,
	  		navigationAllowed: true
	  	})
	  }
	},

	handleSlideLeave(cb) {
		this.setState({
			isLoading: true,
			navigationAllowed: false,
			leavingSlideNum: this.state.currentSlideNum
		})
		this.leavingSlideCb = cb
	},

	prev() {
		this.goToSlide(this.state.currentSlideNum - 1)
	},

	next() {
		this.goToSlide(this.state.currentSlideNum + 1)
	},

	goToSlide(i) {
		if(i < 0 || i > 6) {
			return
		}
		this.setState({
			isLoading: true,
			navigationAllowed: false,
		})
		var routeParams = this.getParams()
		this.transitionTo('slide' + i, routeParams)
	},

	childContextTypes : {
    i18n : React.PropTypes.object,
    lang : React.PropTypes.string
  },

	getChildContext() {
    return {
      i18n : this.props.i18n,
      lang : this.props.lang
    }
  },

  componentDidMount() {
		/** scroll navigation **/
		var scrollTimeout = null
		  , scrollendDelay = 2000
		  , canScroll = true

	  function mouseWheelHandler(e) {
	    e.preventDefault()
	    if(!this.state.navigationAllowed || !canScroll)
	      return

	    var delta = Math.max(-1, Math.min(1, (e.wheelDelta || -e.detail)));
	    var isScrollingDown = delta < 0
      if(isScrollingDown){
      	this.next()
      } else {
      	this.prev()
      }
      canScroll = false
      scrollTimeout = setTimeout(() => {
        canScroll = true
      }, scrollendDelay)
	  }

	  var cmlBody = document.getElementById('cml-slide-container')
	  if (cmlBody.addEventListener) {
	    // IE9, Chrome, Safari, Opera
	    cmlBody.addEventListener("mousewheel", mouseWheelHandler.bind(this), false);
	    // Firefox
	    cmlBody.addEventListener("DOMMouseScroll", mouseWheelHandler.bind(this), false);
	  }

    this.initResize()
  },

  initResize() {
    window.addEventListener('resize', () => {this.resizeCmlContent()})
    this.resizeCmlContent()
  },

  resizeCmlContent() {
    this.setState(viewPort(window))
  },

	render() {

    var cmlContentStyles = {
      width: this.state.width,
      height: this.state.height
    }

    var locales = this.props.i18n.locales

		var theirHeadScript = `
			      var clubmed = {
			          navigation : {
			              version: "" + new Date().getTime(),
			              domain: "${locales.domain}",
			              pays: "${locales.pays}",
			              lang: "${locales.lang}"
			          }
			      };
			`
		var theirScript = `
			      var jsFilename = "http://" + clubmed.navigation.domain + "/cm/be/static/" + clubmed.navigation.version + "/js/home/NavigationExternal.js";

            var jsFile = document.createElement('script');
			          jsFile.setAttribute("type","text/javascript");
			          jsFile.setAttribute("src", jsFilename);
			          document.getElementsByTagName("head")[0].appendChild(jsFile);
			`

		var langScript = `LANG = '${this.props.lang}'`
    var keyName = this.getRoutes().reverse()[0].name;
    var slideNum = parseInt(keyName.charAt(keyName.length-1))

    var loader
    if (this.state.isLoading) {
      loader = <Loader showLoader={this.state.isLoading} />
    }

		return (
			<html lang="fr">
			  <head>
			    <meta charSet="utf-8" />
			    <meta httpEquiv="X-UA-Compatible" content="IE=edge,chrome=1" />
			    <meta name="description" content="" />
			    <meta name="viewport" content="width=device-width,initial-scale=1" />
          <link rel="stylesheet" href="../animationAssets/stylesheets/index.css" />
          <link rel="stylesheet" href="../cm/home/static/navigation_external.css" />

			    <title>ClubMed Luxe</title>
          <script dangerouslySetInnerHTML={{__html:theirHeadScript}} />
			  </head>
			  <body>
          <div id="header"></div>
			  	<div id="cml-content" className="tpl-layout tpl-layout--fluid" style={cmlContentStyles} >
  		  		<div className="cml-container">
  		  			<div className="cml-nav-container">
  		  				<MiddleNav
  		  					ref="navView"
  		  					key="navView"
  		  					langRoute={this.props.langRoute}
  		  					initialSlide={slideNum}
  		  					max={TOTAL_SLIDES}
  		  					navigationHandler={this.goToSlide}
  		  					enabled={this.state.navigationAllowed}  />
  		  			</div>
  		  				<TransitionGroup component="div" id="cml-slide-container">
  			          <TransitionRouteHandler key={keyName} keyName={keyName} onLeave={this.handleSlideLeave} onSVGLoad={this.handleSlideLoad} lang={this.props.lang} />
  			        </TransitionGroup>
  		  		</div>
			  	</div>
          <div id="footerDiv" className="cm-Ref"></div>
          {loader}
          <script src="https://cdnjs.cloudflare.com/ajax/libs/es5-shim/3.4.0/es5-shim.min.js"></script>
          <script src="https://www.promisejs.org/polyfills/promise-6.1.0.js"></script>
			  	<script dangerouslySetInnerHTML={{__html:langScript}} />
			   	<script src="../animationAssets/scripts/bundle.js" />
          <script src="http://cdnjs.cloudflare.com/ajax/libs/require.js/2.1.15/require.min.js" type="application/javascript"></script>
          <script dangerouslySetInnerHTML={{__html:theirScript}} />
			  </body>
			</html>

		)
	}
})

module.exports = App
