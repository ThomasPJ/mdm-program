var React = require('react')
	, config = require('../config')
	, { Route, RouteHandler, Link } = require('react-router')

if(typeof document !== 'undefined') {
	var gsap = require('gsap')
}

var INIT_PAUSE_BEFORE_UNCOLLAPSE = 500
	, INIT_PAUSE_BEFORE_COLLAPSE = 3000 + INIT_PAUSE_BEFORE_UNCOLLAPSE

var MiddleNav = React.createClass({

	contextTypes: {
  	i18n : React.PropTypes.object.isRequired
  },

	getInitialState() {
		return {
			activeSlideNum: this.props.initialSlide,
			isCollapsed: true
		}
	},

	componentWillMount() {
		this.navText = this.context.i18n.nav
		this.menuText = this.context.i18n.menu
	},

	componentDidMount() {

		/** Blur Logo on intro **/
		var BLUR_DURATION = 1
		  , blurElem = {a: 0}
		function applyBlur() {
		  TweenMax.set('.cml-slide__middleNav', {webkitFilter:"blur(" + blurElem.a + "px)"} )
		}
		TweenLite.from(blurElem, BLUR_DURATION, {a:20, onUpdate:applyBlur}, 0 )
	},

	handleLinkClick(e) {
		if(!this.props.enabled) {
			e.preventDefault()
		} else {
			var elem = e.currentTarget
			setTimeout( function() {
				elem.className += " active-expanded"
				setTimeout( function() {
					elem.className = elem.className.replace("active-expanded", "")
				}, 3000)
			}, 200)
			
		}
	},

	render() {

		return (
			<nav role="main" id="hub-nav" className="hub-nav hub-nav-collapsed"  ref="hubNav">
			  <div className="nav-wrapper">
			    <ul>
			      <li className="nav-item nav-item-introduction">
			        <Link to="slide0" onClick={this.handleLinkClick}>
			      		<div className="title-container">
				      		<div className="title-wrapper">
				          	<span className="title">{this.navText[0].title}</span>
				          </div>
			          </div>
			          <span className="nav-item-icon">
					        <svg className="icon-service-item" width="20px" height="20px" viewBox="0 0 210 191" >
										<path className="body" d="M181.721,81.061 C176.898,81.061 172.972,84.988 172.972,89.811 C172.972,89.811 172.972,181.004 172.972,181.004 C172.972,181.004 129.182,181.004 129.182,181.004 C129.182,181.004 129.182,139.3 129.182,139.3 C129.182,134.473 125.258,130.549 120.432,130.549 C120.432,130.549 88.564,130.549 88.564,130.549 C83.738,130.549 79.814,134.473 79.814,139.3 C79.814,139.3 79.814,181.004 79.814,181.004 C79.814,181.004 35.021,181.004 35.021,181.004 C35.021,181.004 35.021,89.811 35.021,89.811 C35.021,84.988 31.096,81.061 26.27,81.061 C26.27,81.061 15.003,81.061 15.003,81.061 C15.003,81.061 103.997,11.006 103.997,11.006 C103.997,11.006 192.992,81.061 192.992,81.061 C192.992,81.061 181.721,81.061 181.721,81.061 Z "/>
										<path className="outline" d="M204.788,78.426 C186.822,64.372 168.856,50.317 150.89,36.263 C143.374,30.382 135.857,24.501 128.34,18.622 C121.91,13.592 116.352,5.642 107.95,3.457 C97.226,0.667 90.201,10.004 82.684,15.886 C73.622,22.974 64.56,30.063 55.498,37.152 C38.44,50.496 21.17,63.609 4.307,77.197 C2.045,79.02 0.204,83.253 1.082,86.244 C2.091,89.679 4.919,89.709 7.989,89.777 C13.849,89.906 19.724,89.777 25.585,89.777 C25.585,89.777 25.585,181.445 25.585,181.445 C25.585,186.192 29.448,190.052 34.192,190.052 C34.192,190.052 78.745,190.052 78.745,190.052 C83.489,190.052 87.353,186.192 87.353,181.445 C87.353,181.445 87.353,140.421 87.353,140.421 C87.353,140.421 120.174,140.421 120.174,140.421 C120.174,140.421 120.174,181.445 120.174,181.445 C120.174,186.192 124.035,190.052 128.781,190.052 C128.781,190.052 173.331,190.052 173.331,190.052 C178.079,190.052 181.938,186.192 181.938,181.445 C181.938,181.445 181.938,89.777 181.938,89.777 C181.938,89.777 200.872,89.777 200.872,89.777 C206.777,89.777 209.4,82.027 204.788,78.426 M180.217,79.448 C175.473,79.448 171.61,83.311 171.61,88.055 C171.61,88.055 171.61,179.723 171.61,179.723 C171.61,179.723 130.503,179.723 130.503,179.723 C130.503,179.723 130.503,138.701 130.503,138.701 C130.503,133.953 126.644,130.093 121.896,130.093 C121.896,130.093 85.631,130.093 85.631,130.093 C80.884,130.093 77.024,133.953 77.024,138.701 C77.024,138.701 77.024,179.723 77.024,179.723 C77.024,179.723 35.914,179.723 35.914,179.723 C35.914,179.723 35.914,88.055 35.914,88.055 C35.914,83.311 32.053,79.448 27.306,79.448 C27.306,79.448 18.191,79.448 18.191,79.448 C18.191,79.448 103.763,12.506 103.763,12.506 C103.763,12.506 189.336,79.448 189.336,79.448 C189.336,79.448 180.217,79.448 180.217,79.448 Z "/>
									</svg>
			      		</span>
			        </Link>
			      </li>
			      <li className="nav-item nav-item-exceptional-places">
			        <Link to="slide1" onClick={this.handleLinkClick}>
			      		<div className="title-container">
			      			<div className="image item-1">
			      			</div>
				          <div className="title-wrapper">
				          	<span className="title">{this.navText[1].title}</span>
				          	<span className="sub-title">{this.navText[1].subtitle}</span>
			          	</div>
			          </div>
			          <span className="nav-item-icon">
			          	<svg viewBox="0 0 35 35" width="20px" height="20px" className="icon-service-item">
			          		<circle cx="17.5" cy="17.5" r="15"/>
			          	</svg>
			          </span>
			        </Link>
			      </li>
			      <li className="nav-item nav-item-sus-mesure">
			        <Link to="slide2" onClick={this.handleLinkClick}>
			      		<div className="title-container">
			      			<div className="image item-2">
			      			</div>
				          <div className="title-wrapper">
				          	<span className="title">{this.navText[2].title}</span>
				          	<span className="sub-title">{this.navText[2].subtitle}</span>
				          </div>
			          </div>
			          <span className="nav-item-icon">
			          	<svg viewBox="0 0 35 35" width="20px" height="20px" className="icon-service-item">
			          		<circle cx="17.5" cy="17.5" r="15"/>
			          	</svg>
			          </span>
			        </Link>
			      </li>
			      <li className="nav-item nav-item-activities">
			        <Link to="slide3" onClick={this.handleLinkClick}>
			      		<div className="title-container">
			      			<div className="image item-3">
			      			</div>
				          <div className="title-wrapper">
				          	<span className="title">{this.navText[3].title}</span>
				          	<span className="sub-title">{this.navText[3].subtitle}</span>
				          </div>
			          </div>
			          <span className="nav-item-icon">
			          	<svg viewBox="0 0 35 35" width="20px" height="20px" className="icon-service-item">
			          		<circle cx="17.5" cy="17.5" r="15"/>
			          	</svg>
			          </span>
			        </Link>
			      </li>
			      <li className="nav-item nav-item-intimacy">
			        <Link to="slide4" onClick={this.handleLinkClick}>
			      		<div className="title-container">
			      			<div className="image item-4">
			      			</div>
				          <div className="title-wrapper">
				          	<span className="title">{this.navText[4].title}</span>
				          	<span className="sub-title">{this.navText[4].subtitle}</span>
				          </div>
			          </div>
			          <span className="nav-item-icon">
			          	<svg viewBox="0 0 35 35" width="20px" height="20px" className="icon-service-item">
			          		<circle cx="17.5" cy="17.5" r="15"/>
			          	</svg>
			          </span>
			        </Link>
			      </li>
			      <li className="nav-item nav-item-children">
			        <Link to="slide5" onClick={this.handleLinkClick}>
			      		<div className="title-container">
			      			<div className="image item-5">
			      			</div>
				          <div className="title-wrapper">
				          	<span className="title">{this.navText[5].title}</span>
				          	<span className="sub-title">{this.navText[5].subtitle}</span>
				          </div>
			          </div>
			          <span className="nav-item-icon">
			          	<svg viewBox="0 0 35 35" width="20px" height="20px" className="icon-service-item">
			          		<circle cx="17.5" cy="17.5" r="15"/>
			          	</svg>
			          </span>
			        </Link>
			      </li>
			      <li className="nav-item nav-item-discover">
			        <Link to="slide6" onClick={this.handleLinkClick}>
			      		<div className="title-container">
			      			<div className="image item-6">
			      			</div>
				          <div className="title-wrapper">
				          	<span className="title">{this.navText[6].title}</span>
				          </div>
			          </div>
			          <span className="peek nav-item-icon">
			          	<svg viewBox="0 0 35 35" width="20px" height="20px" className="icon-service-item">
			          		<circle cx="17.5" cy="17.5" r="15"/>
			          	</svg>
			          </span>
			        </Link>
			      </li>
			    </ul>
			  </div>
			</nav>
		)
	}
})
module.exports = MiddleNav
