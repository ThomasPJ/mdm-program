var $ = require("jquery")
var gsap = require('gsap')

/** Configurations **/
var INTRO_DURATION = 1.1
    , HEXES_DURATION = 0.3
    , HEXES_DELAY = 0.15
    , SHADOW_DURATION = 0.7
    , CONTENT_DURATION = 1.5
    , CONTENT_SLIDE_DISTANCE = 20
    , REPEAT_DELAY = 8

var ANIMATION_STATE = {
  FORWARDS: 1,
  REVERSING: -1,
  IN_DELAY: 0
}

/** Reveal shapes **/
class CmlTimeline {
  constructor(slideNum) {
    this.slideNum = slideNum + 0
    this.progressHistory = [0,0]
    this.timeline = new TimelineMax({
      onStart: () => {
        $('.cml-slide-' + this.slideNum).show()
        this.progressInterval = setInterval(() => {
          this.progressHistory.push(this.timeline.progress())
          this.progressHistory.shift()
        }, 300)
      },
      repeat: -1,
      yoyo: true
    })
  }

  init() {
    var shapesSelector = '.cml-slide-'+this.slideNum+' .cml-slide-shape'
      , shadowShapesSelector = '.cml-slide-'+this.slideNum+' .cml-slide-shadowShape'
      , preheaderSelector = '.cml-slide-'+this.slideNum+' .cml-slide__preheader'
      , titleSelector = '.cml-slide-'+this.slideNum+' .cml-slide__title' +', '+ preheaderSelector
      , subtitleSelector = '.cml-slide-'+this.slideNum+' .cml-slide__subtitle'
      , bodySelector = '.cml-slide-'+this.slideNum+' .cml-slide__body'
    
    /** restore opacities **/
    $.each($(shapesSelector), function() {
      $(this).css('opacity', $(this).attr('opacity'))
    })
    $.each($(shadowShapesSelector), function() {
      $(this).css('opacity', $(this).attr('opacity'))
    })
    this.timeline
      .set({}, {}, INTRO_DURATION)
      .staggerFrom(shapesSelector, HEXES_DURATION, { opacity: 0 }, HEXES_DELAY)
      .to(titleSelector, CONTENT_DURATION, {attr:{ x: "-=" + CONTENT_SLIDE_DISTANCE}, opacity: 1}, "content")
      .to(subtitleSelector, CONTENT_DURATION, {attr:{ x: "-=" + CONTENT_SLIDE_DISTANCE}, opacity: 1}, "content+=0.5" )
      .to(bodySelector, CONTENT_DURATION, {attr:{ x: "-=" + CONTENT_SLIDE_DISTANCE}, opacity: 1}, "content+=1")
      .staggerFrom(shadowShapesSelector, SHADOW_DURATION, { opacity: 0 }, HEXES_DELAY, "content+=2")
      .addLabel('plateau')
      .set({}, {}, "+=" + REPEAT_DELAY/2)
    this.timeline.restart()
  }

  animationState() {
    if(this.timeline.currentLabel() == 'plateau') {
      return ANIMATION_STATE.IN_DELAY
    } else if(this.progressHistory[1] < this.progressHistory[0]) {
      return ANIMATION_STATE.REVERSING
    } else {
      return ANIMATION_STATE.FORWARDS
    }
  }

  stop() {
    if(this.animationState() == ANIMATION_STATE.FORWARDS) {
      this.timeline.reverse()  
    } else if (this.animationState() == ANIMATION_STATE.IN_DELAY) {
      this.timeline.reverse('plateau')
    }
    this.timeline.eventCallback('onRepeat', () => {
      clearInterval(this.progressInterval)
      $('.cml-slide-' + this.slideNum).hide()
      this.timeline.clear()
      this.timeline.kill()
    })
  }

  isActive() {
    return this.timeline.isActive()
  }

  forceStop() {
    $('.cml-slide-' + this.slideNum).hide()
    this.timeline.seek(0)
    this.timeline.pause()
    this.timeline.kill()
  }
}

module.exports = CmlTimeline