var React = require('react')
	, CmlSlide = require('./CmlSlide')
	, config = require('../config')
	, moveNode = require('../utils/moveNode');

if(typeof document !== 'undefined') {
	var gsap = require('gsap')
}

var INTRO_DURATION = 1.1
    , HEXES_DURATION = 0.8
    , HEXES_DELAY = 0.125
    , SHADOW_DURATION = 1.2
    , SHADOW_DELAY = 0.6
    , CONTENT_DURATION = 3.0
    , CONTENT_DELAY = 0.5
    , CONTENT_SLIDE_DISTANCE = 20
    , REPEAT_DELAY = 8
    , BG_FADE_DELAY = 2
    , BG_FADE_DURATION = 0.5
    , SHADOW_FADE_DURATION = 1.5
    , FADE_OUT_SHADOW_DURATION = 1
    , FADE_OUT_BG_DURATION = 2
    , START_NEXT_ANIMATION_AT = 0.75

var shapes, shapes2, shapes3, shadowShapes, shadowShapes2
	, preheader, title, subtitle, body, footer
	, bg1, bg2, bg3, float1, float2

module.exports = React.createClass({
	mixins: [CmlSlide],

	slideNum: 5,
	viewBox: "600 235 1730 900",
	masks: {
		bg: [
      {fillOpacity:"0.6", d:"M1730,630 L1889,630 L1937,779 L1779,779 Z"},
      {fillOpacity:"0.5", d:"M1604,722 L1730,630 L1779,779 L1653,869 Z"},
      {fillOpacity:"0.9", d:"M1477,630 L1606,536 L1654,391 L1782,482 L1937,480 L1889,630 L1730,630 L1604,722 Z"},
      {fillOpacity:"0.6", d:"M1779,933 L1779,779 L1871,904 L1873,1062 Z"},
      {fillOpacity:"0.4", d:"M1937,480 L2028,354 L2176,306 L2085,433 Z"},
      {fillOpacity:"0.6", d:"M1730,630 L1858,240 L2268,240 L2140,630 L2268,1019 L1858,1019 Z"},
      {fillOpacity:"0.4", d:"M2061,573 L2092,480 L2171,537 L2140,630 Z M2140,630 L2267,722 L2219,869 L2092,779 Z"},
      {fillOpacity:"0.8", d:"M1985,630 L2061,573 L2140,630 L2171,537 L2267,537 L2238,630 L2267,722 L2170,721 L2092,779 L2062,687 Z"},
      {fillOpacity:"0.9", d:"M2140,533 L2198,454 L2196,552 L2140,630 Z M2062,687 L2140,630 L2170,721 L2092,779 Z"},
      {fillOpacity:"0.6", d:"M1401,390 L1527,0 L1858,240 L1730,630 L1401,870 L1069,630 Z"},
      {fillOpacity:"0.4", d:"M0,630 L894,0 L1730,630 L1858,1019 L1527,1260 L1401,870 L866,1260 Z"},
		],
		extra: [
      {fillOpacity:"0.8", d:"M1477,630 L1606,536 L1730,630 L1604,722 Z"},
      {fillOpacity:"0.6", d:"M1730,630 L1889,630 L1937,779 L1779,779 Z"},
      {fillOpacity:"0.4", d:"M1604,722 L1730,630 L1779,779 L1653,869 Z"},
      {fillOpacity:"1.0", d:"M1606,536 L1654,391 L1782,482 L1937,480 L1889,630 L1730,630 Z"},
      {fillOpacity:"0.6", d:"M1889,630 L1937,613 L1985,630 L1934,646 Z"}
		]
	},

	images: {
		bg: [
			{
			  src: config.assetsServer + '/animationAssets/images/slide6-hero-a.jpg',
			  x: 500,
			  y: -100,
			  width: 1880,
			  height: 1292
			},
			{
			  src: config.assetsServer + '/animationAssets/images/slide6-hero-b.jpg',
			  x: 500,
			  y: -100,
			  width: 1880,
			  height: 1292
			}
		],
	extra: []
	},

	preheaderOptions: {
		init: {
			x: 1300,
			y: 370,
		},
		dy: {
			preheader: 17
		},
		x: (y) => {
			return 1300
		},
		textAnchor: 'end'
	},

	textOptions: {
		init: {
			x: 1360,
			y: 380,
		},
		dy: {
			preheader: 0,
			titleTopMargin: 50,
			title: 25,
			subtitleTopMargin: 0,
			subtitle: 30,
			body: 20
		},
		x: (y) => {
			return -1.5 * (y-400) + 1360
		},
		textAnchor: 'end'
	},

	footerOptions: {
		init: {
			x: 1090,
			y: 720,
		},
		dy: {
			footer: 17
		},
		x: (y) => {
			return 1.5 * (y-720) + 1090
		},
		textAnchor: 'end'
	},

	start(isMovingUp) {
		if(isMovingUp === true) {
			var slidingTimeline = new TimelineMax
			slidingTimeline.from(this.getDOMNode(), config.SLIDING_DURATION, {top: '100%'})
		} else if (isMovingUp === false) {
			var slidingTimeline = new TimelineMax
			slidingTimeline.from(this.getDOMNode(), config.SLIDING_DURATION, {top: '-100%'})
		}
		var svg = this.getDOMNode()
		svg.style.display = 'block'

		shapes = svg.querySelectorAll('.cml-slide-shape-0')
		shapes2 = svg.querySelectorAll('.cml-slide-shape-1')
		preheader = svg.querySelectorAll('.cml-slide__preheader')
		title = svg.querySelectorAll('.cml-slide__title')
		subtitle = svg.querySelectorAll('.cml-slide__subtitle')
		body = svg.querySelectorAll('.cml-slide__body')
		footer = svg.querySelectorAll('.cml-slide__footer')
		bg1 = svg.querySelector('#bg-0')
		bg2 = svg.querySelector('#bg-1')

		bg2.style.opacity = 0


		/* version text et anims asynchrones */
		// var initTimeline = new TimelineMax
		// initTimeline
		// 	.to(preheader, CONTENT_DURATION, {fillOpacity: 1, onUpdate: moveNode}, "content")
		// 	.to(title, CONTENT_DURATION, {fillOpacity: 1, onUpdate: moveNode}, "content+=" + CONTENT_DELAY)
		// 	.to(subtitle, CONTENT_DURATION, {fillOpacity: 1, onUpdate: moveNode}, "content+=" + CONTENT_DELAY)
		// 	.to(body, CONTENT_DURATION, {fillOpacity: 1, onUpdate: moveNode}, "content+=" + CONTENT_DELAY)
		// 	.to(footer, CONTENT_DURATION, {fillOpacity: 1, onUpdate: moveNode}, "content+=" + CONTENT_DELAY)
		// 	.stop()

		// this.timeline = new TimelineMax()
		// this.timeline
		// 	.staggerFrom(shapes, HEXES_DURATION, { fillOpacity: 0 }, HEXES_DELAY)
		// 	.call(() => {
		// 		initTimeline.play()
		// 	}, null, null, "text")

		// 	/** Render first extra **/
		// 	.addLabel('renderbg2', "text+=2.5")
		// 	.set({}, {}, "+=3")

		// 	/** 2nd bg **/
		// 	.to(bg1, 0.5, {opacity: 0}, 'renderbg2')
		// 	.set(bg2, {opacity: 1}, 'renderbg2')
		// 	.staggerFrom(shapes2, HEXES_DURATION, { fillOpacity: 0 }, HEXES_DELAY, 'renderbg2')

		// 	.set({}, {}, "+=" + REPEAT_DELAY/2)


		/* version text et anims asynchrones */
		var initTimeline = new TimelineMax
		initTimeline
			.to(preheader, CONTENT_DURATION, {fillOpacity: 1, onUpdate: moveNode}, "content")
			.to(title, CONTENT_DURATION, {fillOpacity: 1, onUpdate: moveNode}, "content+=" + CONTENT_DELAY)
			.to(subtitle, CONTENT_DURATION, {fillOpacity: 1, onUpdate: moveNode}, "content+=" + CONTENT_DELAY)
			.to(body, CONTENT_DURATION, {fillOpacity: 1, onUpdate: moveNode}, "content+=" + CONTENT_DELAY)
			.to(footer, CONTENT_DURATION, {fillOpacity: 1, onUpdate: moveNode}, "content+=" + CONTENT_DELAY)
			.stop()

		this.timeline = new TimelineMax()
		this.timeline

			// anim
			.staggerFrom(shapes, HEXES_DURATION, { fillOpacity: 0 }, HEXES_DELAY, "start")

			// text
			.to(preheader, CONTENT_DURATION, {fillOpacity: 1}, "start")

			// text
			.to(title, CONTENT_DURATION, {fillOpacity: 1}, "start+=" + (HEXES_DURATION + HEXES_DELAY))
			.to(subtitle, CONTENT_DURATION, {fillOpacity: 1}, "start+=" + (HEXES_DURATION + HEXES_DELAY))

			.addLabel("renderbg2", "start+=" + (HEXES_DURATION + BG_FADE_DELAY))

			/** 2nd bg **/
			.to(bg1, 0.5, {opacity: 0}, "renderbg2")
			.staggerFrom(shapes2, HEXES_DURATION, { fillOpacity: 0 }, HEXES_DELAY, "renderbg2")
			.set(bg2, {opacity: 1}, "renderbg2")

			// text
			.to(body, CONTENT_DURATION, {fillOpacity: 1}, "renderbg2")

			// text
			.to(footer, CONTENT_DURATION, {fillOpacity: 1}, "renderbg2+=" + (HEXES_DURATION + HEXES_DELAY))

			// useful if this.timeline.repeat is set to repeat anim
			.set({}, {}, "+=" + REPEAT_DELAY/2)

		this.timeline.repeat(0)
		this.timeline.restart()
	},

	stop(isMovingUp, readyForNextCb, doneStoppingCb) {
	  this.timeline.pause()

	  var shapesRev = Array.prototype.slice.call(shapes,0).reverse()
	  var shapes2Rev = Array.prototype.slice.call(shapes2,0).reverse()

	  var fadeOutTimeline = new TimelineMax()
	  fadeOutTimeline
	  	.to(preheader, CONTENT_DURATION, {fillOpacity: 0}, "fadeOut+="+1)
	  	.to(title, CONTENT_DURATION, {fillOpacity: 0}, "fadeOut+="+1)
	  	.to(subtitle, CONTENT_DURATION, {fillOpacity: 0}, "fadeOut+="+1)
	  	.to(body, CONTENT_DURATION, {fillOpacity: 0}, "fadeOut+="+1)
	  	.to(footer, CONTENT_DURATION, {fillOpacity: 0}, "fadeOut+="+1)
	  	.staggerTo(shapesRev, HEXES_DURATION, { fillOpacity: 0 }, HEXES_DELAY, 'fadeOut+='+1)
	  	.staggerTo(shapes2Rev, HEXES_DURATION, { fillOpacity: 0 }, HEXES_DELAY, 'fadeOut+='+1)
	  fadeOutTimeline.play()

	  // start next timeline if a certain progress is acheived
	  var hasCalledReadyForNextCb = false
		fadeOutTimeline.eventCallback('onUpdate', () => {
	    if(fadeOutTimeline.progress() > START_NEXT_ANIMATION_AT && !hasCalledReadyForNextCb) {
	      hasCalledReadyForNextCb = true
		    readyForNextCb()
	    }
	  })

	  fadeOutTimeline.eventCallback('onComplete', () => {
			if(isMovingUp === true) {
				var slidingTimeline = new TimelineMax
				slidingTimeline.to(this.getDOMNode(), config.SLIDING_DURATION, {top: '-100%'})
			} else if (isMovingUp === false) {
				var slidingTimeline = new TimelineMax
				slidingTimeline.to(this.getDOMNode(), config.SLIDING_DURATION, {top: '100%'})
			}
			this.forceStop(doneStoppingCb)
		})
	}
})
