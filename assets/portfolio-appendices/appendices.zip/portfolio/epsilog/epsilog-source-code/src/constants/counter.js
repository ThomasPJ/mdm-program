import { createConstants } from '../utils';

export default createConstants(
  'COUNTER_INCREMENT'
);
