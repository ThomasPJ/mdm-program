import React                  from 'react'
import { Link }               from 'react-router'
import Parse                  from 'parse'
import { connect }            from 'react-redux'
import { bindActionCreators } from 'redux'
import { updatePath } from 'redux-simple-router'
import classNames             from 'classnames'
import LoginForm              from 'components/Home/LoginForm'
import ForgotForm             from 'components/Home/ForgotForm'
import RegisterForm           from 'components/Home/RegisterForm'

class Login extends React.Component {

  state = {
    isShowingForgotPasswordForm: false
  }

  toggleForgotPasswordForm = () => {
    this.setState({
      isShowingForgotPasswordForm: !this.state.isShowingForgotPasswordForm
    })
  }

  render () {
    return (
      <div className='container px2'>
        <div className="clearfix mxn2">
          <div className="sm-col sm-col-3 px2">
            {!this.state.isShowingForgotPasswordForm ?
              <LoginForm toggleForgotPasswordForm={this.toggleForgotPasswordForm}/> :
              <ForgotForm toggleForgotPasswordForm={this.toggleForgotPasswordForm}/> }
          </div>
          <div className="sm-col sm-col-3 px2">
            <RegisterForm />
          </div>
        </div>
      </div>
    )
  }
}

export default Login
