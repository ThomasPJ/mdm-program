import React                  from 'react';
import calculatorActions      from 'actions/calculator';
import { connect }            from 'react-redux'
import { bindActionCreators } from 'redux'
import Parse                  from 'parse';
import Select                 from 'react-select'

const SEARCH_TIMER = 500

const mapStateToProps = (state) => ({
  calculator: state.calculator,
  routing: state.routing
})
const mapDispatchToProps = (dispatch) => ({
  actions : bindActionCreators(calculatorActions, dispatch)
})

export class Directions extends React.Component {
  static contextTypes = {
    simulationId: React.PropTypes.string
  }

  originTimer = null
  destinationTimer = null

  handleOriginChange = (keyword, cb) => {
    if(this.originTimer) {
      clearTimeout(this.originTimer)
    }
    this.originTimer = setTimeout(() => {
      this.search(keyword).then(response => {
        cb(null, {
          options: response.predictions.map(location => ({ value: location.description, label: location.description })),
        })
      })
    }, SEARCH_TIMER)
  }

  handleDestinationChange = (keyword, cb) => {
    if(this.destinationTimer) {
      clearTimeout(this.destinationTimer)
    }
    this.destinationTimer = setTimeout(() => {
      this.search(keyword).then(response => {
        cb(null, {
          options: response.predictions.map(location => ({ value: location.description, label: location.description })),
        })
      })
    }, SEARCH_TIMER)
  }

  search = (keyword) => {
    return Parse.Cloud.run('autocomplete', {keyword})
  }

  chooseOrigin = (location) => {
    this.props.actions.setOrigin(this.context.simulationId, location)
  }

  chooseDestination = (location) => {
    this.props.actions.setDestination(this.context.simulationId, location)
  }

  handleTariffChange = (e) => {
    const newTariff = !!parseInt(e.target.value)
    this.props.actions.updateTariff (this.context.simulationId, newTariff)
  }

  render = () => {
    const simulation = this.props.calculator[this.context.simulationId]
    if(!simulation) {
      return null
    }
    const tariff = simulation.tariff
    const tariffValue = tariff === null ? null : (tariff ? 1 : 0)

    return (
      <div>
        <div className='input-Row clearfix'>
          <div className="input-Item sm-col sm-col-3 mr3">
            <label>Grille</label>
            <select className="block field" onChange={this.handleTariffChange} value={tariffValue}>
              <option value={0}>Simple</option>
              <option value={1}>Complexe</option>
            </select>
          </div>
          <div className="input-Item depart-Item sm-col sm-col-3 mr3">
            <label>Départ</label>
            <Select
              name="origin-input"
              value={simulation.origin}
              onChange={this.chooseOrigin}
              autoload={false}
              asyncOptions={this.handleOriginChange}
              placeholder="Point de départ..."
              searchingText="Recherche en cours"
              searchPromptText="Entrez un point de départ"
              />
          </div>
          <div className="input-Item destination-Item sm-col sm-col-3 mr3">
            <label>Destination</label>
            <Select
              name="destination-input"
              value={simulation.destination}
              onChange={this.chooseDestination}
              autoload={false}
              asyncOptions={this.handleDestinationChange}
              placeholder="Point de livraison..."
              searchingText="Recherche en cours"
              searchPromptText="Entrez un point de livraison"
              />
          </div>
        </div>
      </div>
    );
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Directions)
