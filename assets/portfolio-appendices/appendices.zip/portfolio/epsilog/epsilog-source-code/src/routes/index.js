import React                 from 'react';
import { Route, IndexRoute } from 'react-router';
import CoreLayout            from 'layouts/CoreLayout';
import Login                 from 'views/Login';
import ClientSimulator       from 'views/ClientSimulator';
import AccountView           from 'views/AccountView';
import History               from 'views/History';
import Legal                 from 'views/Legal';
import Dashboard             from 'views/Dashboard';
import Share                 from 'views/Share';
import Parse                 from 'parse'

var requireAuth = (nextState, replaceState) => {
  if (Parse.User.current() === null)
    replaceState({ nextPathname: nextState.location.pathname }, '')
}

var redirectIfLoggedIn = (nextState, replaceState) => {
  if (Parse.User.current() !== null)
    replaceState({ nextPathname: nextState.location.pathname }, '/simulator/new')
}

export default (
  <Route        component={CoreLayout} path='/'>
    <IndexRoute component={Login} onEnter={redirectIfLoggedIn} />
    <Route      component={ClientSimulator}  path='/simulator/:simulationId' onEnter={requireAuth} />
    <Route      component={Share}  path='/share/:simulationId' />
    <Route      component={Dashboard}  path='/dashboard' onEnter={requireAuth} />
    <Route      component={History}  path='/history' onEnter={requireAuth} />
    <Route      component={AccountView}  path='/account' onEnter={requireAuth} />
    <Route      component={Legal}  path='/mentions-legales' />
  </Route>
);
