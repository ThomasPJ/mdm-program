require('babel/register');
module.exports = require('./build/karma');
