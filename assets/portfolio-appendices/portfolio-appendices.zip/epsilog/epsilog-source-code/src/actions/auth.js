import Parse from 'parse'

export function getUserRoleRequest() {
  return {
    type: 'GET_USER_ROLE_REQUEST'
  };
}

export function getUserRoleSuccess(role) {
  return {
    type: 'GET_USER_ROLE_SUCCESS',
    payload: role
  };
}

export function getUserRoleFailure() {
  return {
    type: 'GET_USER_ROLE_FAILURE'
  };
}
export function getUserRole(userId) {
  return dispatch => {
    dispatch(getUserRoleRequest);
    var superadminQuery = (new Parse.Query(Parse.Role))
    superadminQuery.equalTo("name", "superadmin")
    var adminQuery = (new Parse.Query(Parse.Role))
    adminQuery.equalTo("name", "admin")

    var roleQuery = Parse.Query.or(adminQuery, superadminQuery)
    roleQuery.equalTo("users", Parse.User.current())
    return roleQuery.first().then(role => {
      dispatch(getUserRoleSuccess(role));
    })
  };
}