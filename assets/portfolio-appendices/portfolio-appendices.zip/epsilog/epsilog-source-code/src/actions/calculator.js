export default {
	reset:  (simulationId) => ({ type : 'RESET', payload: {simulationId} }),
	restore:  (simulationId, simulation) => ({ type : 'RESTORE', payload: {simulationId, simulation} }),
	remove:  (simulationId) => ({ type : 'REMOVE', payload: {simulationId} }),
	setOrigin:  (simulationId, origin) => ({ type : 'SET_ORIGIN', payload: {simulationId, origin} }),
	setDestination:  (simulationId, destination) => ({ type : 'SET_DESTINATION', payload: {simulationId, destination} }),
	addCargoItem:  (simulationId) => ({ type : 'ADD_CARGO_ITEM', payload: {simulationId}}),
	removeCargoItem:  (simulationId, i) => ({ type : 'REMOVE_CARGO_ITEM', payload:  {simulationId, i}}),
	changeItemType:  (simulationId, i, type) => ({ type : 'CHANGE_ITEM_TYPE', payload:  {simulationId, i, type}}),
	changeItemModel:  (simulationId, i, model) => ({ type : 'CHANGE_ITEM_MODEL', payload:  {simulationId, i, model}}),
	changeItemQuantity:  (simulationId, i, quantity) => ({ type : 'CHANGE_ITEM_QUANTITY', payload:  {simulationId, i, quantity}}),
  updateTariff:  (simulationId, isComplex) => ({ type : 'UPDATE_TARIFF', payload: {simulationId, isComplex} }),
  updateIs24h:  (simulationId, is24h) => ({ type : 'UPDATE_IS24H', payload: {simulationId, is24h} })
};