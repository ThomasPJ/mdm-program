import { COUNTER_INCREMENT } from 'constants/counter';

export default {
  increment: () => ({ type : COUNTER_INCREMENT })
};
