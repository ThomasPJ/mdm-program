import React from 'react'
import moment from 'moment'
import cargoModels from 'components/Simulator/cargoModels';
import ParseReact             from 'parse-react';
import Parse                  from 'parse'
import { connect }            from 'react-redux'
import { bindActionCreators } from 'redux'
import { updatePath }         from 'redux-simple-router'
import calculatorActions      from 'actions/calculator';
import {isEmpty}              from 'ramda'
import CopyToClipboard from 'react-copy-to-clipboard';
import classNames             from 'classnames'

const mapStateToProps = (state) => ({
  calculator: state.calculator,
  auth: state.auth
})
const mapDispatchToProps = (dispatch) => ({
  actions : bindActionCreators(calculatorActions, dispatch),
  updatePath : bindActionCreators(updatePath, dispatch)
})

export class Simulation extends React.Component {
	state = {
		removeClicked: false,
    isShowShare: false
	}

	restore = (simulation) => {
	  const simulationId = simulation.id.objectId
	  this.props.actions.restore(simulationId, simulation)
	  this.props.updatePath('/simulator/' + simulationId)
	}

	remove = (simulation) => {
	  const simulationId = simulation.id.objectId

	  if(this.state.removeClicked) {
	    ParseReact.Mutation.Destroy(simulation).dispatch()
	    this.props.actions.remove(simulationId)
	  } else {
	    this.setState({removeClicked: true})
	  }
	}

	cancelRemove = (simulation) => {
	  const simulationId = simulation.id.objectId
	  this.setState({removeClicked: false})
	}

	generateCargoItem = (cargoItem, i) => {
    const type = cargoModels[cargoItem.type]
    if(!type) {
      return null
    }
    const typeName = type.name
    const model = type.models[cargoItem.model]
    if(!model) {
      return null
    }
    const modelName = model.name
    const quantity = cargoItem.quantity

    return (
      <div className='history-Entry clearfix' key={i}>
        <div className="input-Item sm-col sm-col-3">{typeName}</div>
        <div className="input-Item sm-col sm-col-3">{modelName}</div>
        <div className="input-Item sm-col sm-col-3">{quantity}</div>
      </div>
    )
  }

  share = simulation => {
    this.setState({isShowShare: true})
  }

	render() {
		const simulation = this.props.simulation
		const tariffName = simulation.tariff ? 'Complexe' : 'Simple'
		const distance = simulation.distance

    var buttonsRemove = (
      <div className='sm-col button-Container'>
        <button className="btn btn-outline mr1 black" onClick={this.cancelRemove.bind(this, simulation)}>Annuler</button>
        <button className="btn btn-outline red" onClick={this.remove.bind(this, simulation)}>Effacer</button>
      </div>
    )

		if(this.props.isReadOnly) {
      if(this.props.auth.role === 'superadmin') {
        var buttonsNormal = (
          <div className='sm-col button-Container'>
            <button className="btn btn-outline mr1 red" onClick={this.remove.bind(this, simulation)}>Effacer</button>
          </div>
        )  
      } else {
        var buttonsNormal = null
      }
		} else {
			var buttonsNormal = (
	      <div className='sm-col button-Container'>
          <button className="btn btn-outline mr1 blue" onClick={this.share.bind(this, simulation)}>Partager</button>
          <button className="btn btn-outline mr1 blue" onClick={this.restore.bind(this, simulation)}>Modifier</button>
        </div>
	    )
		}

    var buttons = this.state.removeClicked ? buttonsRemove : buttonsNormal

    const authorComponent = this.props.isShowAuthor && !isEmpty(simulation.author) ?
      <div className='sm-col author-Entry'>
        {this.props.isReadOnly ? `${simulation.author.name}, ${simulation.author.email}, ${simulation.author.company}` : null}
      </div>
    : null

    var containerClasses = classNames({
      'simulation-Container': true,
      'clearfix': true,
      'simulation-Container__new': this.props.isNew === true
    })
    var shareUrl = `${window.location.host}/#/share/${simulation.id.objectId}?token=${simulation.token}`
		return (
		  <div className={containerClasses} key={simulation.id.objectId}>
        <div className='history-Entry-Container sm-col sm-col-12'>
          <div className='history-Entry-Date sm-col'>
            Simulation du <strong>{moment(simulation.createdAt).format('dddd, Do MMMM YYYY, h:mm:ss a')}</strong>
          </div>
        </div>
        {authorComponent}
        <div className='sm-col sm-col-12 title-Inputs'>
          <div className="input-Item sm-col sm-col-3">
            <label>Type</label>
          </div>
          <div className="input-Item sm-col sm-col-3">
            <label>Modèle</label>
          </div>
          <div className="input-Item sm-col sm-col-3">
            <label>Quantité</label>
          </div>
        </div>
        <div className='sm-col sm-col-12'>
          {simulation.cargoItems ? simulation.cargoItems.map(this.generateCargoItem) : null}
        </div>
        <div className='sm-col sm-col-12'>
          <div className='criteria-Block'>
            <label>Critères</label>
            <ul className='criteria-List'>
              <li>Tarif : {tariffName}</li>
              <li>Distance : {Math.round(simulation.distance / 1000)}km ({simulation.origin} - {simulation.destination})</li>
              <li>{simulation.is24h ? 'Livraison en 24h' : ''}</li>
            </ul>
          </div>


          <div className='clearfix sm-col result-Container'>
            {buttons}
            <div className='sm-col'><h3>Total {simulation.price} €</h3></div>
          </div>

        </div>
        { this.state.isShowShare ?
          <div className="clearfix sm-col sm-col-12">
            <h4>URL de partage :</h4>
            <div className="flex col col-12 sm-col-6">
              <input className="field flex-auto share-Input" type="text" value={shareUrl} readOnly />
              <CopyToClipboard text={shareUrl}
                onCopy={() => this.setState({copied: true})}>
                <button className="btn btn-primary">Copier</button>
              </CopyToClipboard>
            </div>
          </div> :
          null }
      </div>
		)
	}
}

export default connect(mapStateToProps, mapDispatchToProps)(Simulation)
