import React                  from 'react'
import { Link }               from 'react-router'
import Parse                  from 'parse'
import { connect }            from 'react-redux'
import { bindActionCreators } from 'redux'
import { updatePath } 				from 'redux-simple-router'
import classNames             from 'classnames'

const mapStateToProps = (state) => ({})
const mapDispatchToProps = (dispatch) => ({
  updatePath : bindActionCreators(updatePath, dispatch)
})
class LoginForm extends React.Component {
	state = {
	  email: '',
    password: '',
    isSubmitted: false,
    isError: false,
    isShowingForgotPasswordForm: false,
	}

	handleEmailChange = (e) => {
	  this.setState({
	    email: e.target.value
	  })
	}

	handlePasswordChange = (e) => {
	  this.setState({
	    password: e.target.value
	  })
	}

	setError = (isError) => {
	  this.setState({
	    isError: isError,
	    isSubmitted: false
	  })
	}

	login = (event)  => {
	  event.preventDefault()
	  if(this.state.isSubmitted)
	    return

	  this.setState({
	    isSubmitted: true
	  })
	  Parse.User.logIn(this.state.email, this.state.password).then(() => {
	    this.props.updatePath('/simulator/new')
	  }, () => {
	    this.setError(true)
	  })
	}

	toggleForgotPassword = () => {
		this.props.toggleForgotPassword()

	}

	forgotPassword = (e) => {
		e.preventDefault()
		if(this.state.isSubmitted)
		  return

		this.setState({
	    isSubmitted: true
	  })

		Parse.User.requestPasswordReset(this.state.email, {
		  success: () => {
	  		this.setState({
	  	    isSubmitted: false,
	  	    isError: false,
	  	    isEmailSent: true,
	  	    message: `Un email de récupération de mot de passe a été envoyé à l'adresse suivante: ${this.state.email}`
	  	  })
		  },
		  error: error => {
		  	switch(error.code) {
		  	case Parse.Error.EMAIL_MISSING:
		  		var message = `Veuillez saisir une adresse email`
		  		break
		  	case Parse.Error.EMAIL_NOT_FOUND:
		  		var message = `L'adresse email ${this.state.email} est inconnue`
		  		break
		  	case Parse.Error.INVALID_EMAIL_ADDRESS:
		  		var message = `Adresse email incorrecte`
		  		break
		  	default:
		  		var message: 'Error'
		  		break
		  	}

	    	this.setState({
	        isSubmitted: false,
	        isError: true,
	        message: message
	      })
		  }
		})
	}

	render() {
		var fieldClasses = classNames({
		  'field': true,
		  'is-error':this.state.isError
		})

		// Render page
		return (
			<form onSubmit={this.forgotPassword}>
			  <h2>Mot de passe oublié</h2>
			  <div className="mb2">
			    <input
			      type="text"
			      className={fieldClasses}
			      placeholder="Saisissez votre email"
			      onChange={this.handleEmailChange}
			      value={this.state.email}/>
			  </div>

			  <div className="">
			    <input type="submit" className="btn btn-primary" onClick={this.forgotPassword} value={this.state.isSubmitted ? 'Envoi...' : 'Envoyer'}/>
			  </div>
			  <div className="mt1">
			    <input
			    	type="button"
			    	className="btn btn-primary bg-silver black"
			    	value="Annuler"
			    	onClick={this.props.toggleForgotPasswordForm}/>
			  </div>
			  <div className={classNames({mt1: true, red: this.state.isError, green: !this.state.isError})}>
			  	{this.state.message}
			  </div>
			</form>
		)
	}
}
export default connect(mapStateToProps, mapDispatchToProps)(LoginForm)
