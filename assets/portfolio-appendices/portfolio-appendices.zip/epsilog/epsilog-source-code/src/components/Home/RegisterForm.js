import React                  from 'react'
import { Link }               from 'react-router'
import Parse                  from 'parse'
import { connect }            from 'react-redux'
import { bindActionCreators } from 'redux'
import { updatePath } 				from 'redux-simple-router'
import classNames             from 'classnames'

const mapStateToProps = (state) => ({})
const mapDispatchToProps = (dispatch) => ({
  updatePath : bindActionCreators(updatePath, dispatch)
})
class LoginForm extends React.Component {
	state = {
		name: '',
	  email: '',
    password: '',
    company: '',
    isSubmitted: false,
    isError: false,
    tcAgreed: false,
    tcError: false
	}

	handleNameChange = (e) => {
	  this.setState({
	    name: e.target.value
	  })
	}

	handleEmailChange = (e) => {
	  this.setState({
	    email: e.target.value
	  })
	}

	handlePasswordChange = (e) => {
	  this.setState({
	    password: e.target.value
	  })
	}

	handleCompanyChange = (e) => {
	  this.setState({
	    company: e.target.value
	  })
	}

	handleTCChange = e => {
		this.setState({
			tcAgreed: e.target.checked
		})
	}

	setError = (isError) => {
	  this.setState({
	    isError: isError
	  })
	}

	register = (event) => {
	  event.preventDefault()
	  if(this.state.isSubmitted)
	    return

	  if(!this.state.tcAgreed) {
	  	this.setState({
				tcError: true
	  	})
	    return
	  }

	  this.setState({
	    isSubmitted: true,
	    tcError: false,
	    isError: false
	  })
	  
	  var user = new Parse.User()
	  user.set("username", this.state.email)
	  user.set("password", this.state.password)
	  user.set("email", this.state.email)
	  user.set("name", this.state.name)
	  user.set("company", this.state.company)

	  user.signUp(null).then(user => {
	    Parse.User.logIn(this.state.email, this.state.password).then(() => {
	      this.props.updatePath('/simulator/new')
	    }, () => {
	      this.setError(true)
	    })
	  }, (user, error) => {
	    this.setState({
	    	isError: true,
	      isSubmitted: false
	    })
	  })
	}

	render = () => {
		var fieldClasses = classNames({
		  'field': true,
		  'is-error':this.state.isError
		})
		return (
			<form onSubmit={this.register}>
			  <h2>Créer un compte</h2>
			  <div className="mb2">
			     <input
			     	type="text"
			     	className={fieldClasses}
			     	placeholder="Nom"
			     	value={this.state.name}
			     	onChange={this.handleNameChange}/>
			  </div>
			  <div className="mb2">
			    <input
			      type="text"
			      className={fieldClasses}
			      placeholder="Email"
			      onChange={this.handleEmailChange}
			      value={this.state.email}
			       />
			  </div>
			  <div className="mb2">
			    <input
			      type="password"
			      className={fieldClasses}
			      placeholder="Mot de passe"
			      onChange={this.handlePasswordChange}
			      value={this.state.password}/>
			  </div>
			  <div className="mb2">
		      <input
		      	type="text"
		      	className={fieldClasses}
		      	placeholder="Agence"
		      	value={this.state.company}
		      	onChange={this.handleCompanyChange}/>
			  </div>
        <div className="mb2">
          <input
            type="checkbox"
            checked={this.state.tcAgreed}
            onChange={this.handleTCChange}
            />
          <span className="form-cgu" style={{color: this.state.tcError ? 'red' : undefined}}>
            J'accepte les <Link to="/mentions-legales" target="_blank"  style={{color: this.state.tcError ? 'red' : undefined}}>Conditions Générales d'Utilisation</Link>
          </span>
        </div>
			  <div className="">
			    <input type="submit" className="btn btn-primary" value={this.state.isSubmitted ? 'Registering...' : 'Créer'}/>
			  </div>
			</form>
		)
	}
}
export default connect(mapStateToProps, mapDispatchToProps)(LoginForm)
