import React                  from 'react'
import { Link }               from 'react-router'
import Parse                  from 'parse'
import { connect }            from 'react-redux'
import { bindActionCreators } from 'redux'
import { updatePath } 				from 'redux-simple-router'
import classNames             from 'classnames'

const mapStateToProps = (state) => ({})
const mapDispatchToProps = (dispatch) => ({
  updatePath : bindActionCreators(updatePath, dispatch)
})
class LoginForm extends React.Component {
	state = {
	  email: '',
    password: '',
    isSubmitted: false,
    isError: false
	}

	handleEmailChange = (e) => {
	  this.setState({
	    email: e.target.value
	  })
	}

	handlePasswordChange = (e) => {
	  this.setState({
	    password: e.target.value
	  })
	}

	setError = (isError) => {
	  this.setState({
	    isError: isError,
	    isSubmitted: false
	  })
	}

	login = (event)  => {
	  event.preventDefault()
	  if(this.state.isSubmitted)
	    return

	  this.setState({
	    isSubmitted: true
	  })
	  Parse.User.logIn(this.state.email, this.state.password).then(() => {
	    this.props.updatePath('/simulator/new')
	  }, () => {
	    this.setError(true)
	  })
	}

	render() {
		var fieldClasses = classNames({
		  'field': true,
		  'is-error':this.state.isError
		})
		return (
			<form onSubmit={this.login}>
			  <h2>Login</h2>
			  <div className="mb2">
			    <input
			      type="text"
			      className={fieldClasses}
			      placeholder="Email"
			      onChange={this.handleEmailChange}
			      value={this.state.email}/>
			  </div>
			  <div className="mb2">
			    <input
			      type="password"
			      className={fieldClasses}
			      placeholder="Mot de passe"
			      onChange={this.handlePasswordChange}
			      value={this.state.password}/>
			  </div>
			  <div className="">
			    <input type="submit" className="btn btn-primary" value={this.state.isSubmitted ? 'Logging In...' : 'Login'}/>
			  </div>
			  <div className="mt1">
			    <a className="forgotten-Pass" onClick={this.props.toggleForgotPasswordForm}>Mot de passe oublié ?</a>
			  </div>
			</form>
		)
	}
}
export default connect(mapStateToProps, mapDispatchToProps)(LoginForm)
