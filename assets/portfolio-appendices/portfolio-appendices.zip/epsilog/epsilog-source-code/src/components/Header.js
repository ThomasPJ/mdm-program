import React                  from 'react';
import { Link }               from 'react-router';
import { connect }            from 'react-redux'
import { bindActionCreators } from 'redux'
import { updatePath }         from 'redux-simple-router'
import * as authActions            from 'actions/auth'
import Parse                  from 'parse'
import ParseReact             from 'parse-react'
import hero                   from 'img/hero.jpg'
import jg                   from 'img/jg.svg'
import {isEmpty, prop}              from 'ramda'

var ParseComponent = ParseReact.Component(React);

const mapStateToProps = (state) => ({
  auth: state.auth
})
const mapDispatchToProps = (dispatch) => ({
  updatePath : bindActionCreators(updatePath, dispatch),
  actions: {
    auth : bindActionCreators(authActions, dispatch),
  }
})

var styles = {
  hero: {
      backgroundImage: 'url(' + hero + ')',
  }
}

export class Header extends ParseComponent {

  logout = () => {
    Parse.User.logOut().then(() => {
      this.props.updatePath('/')
    })
  }

  state = {
    isAdmin: false
  }

  observe(props, state) {
    return {
      currentUser: ParseReact.currentUser
    }
  }

  prevUser = null

  componentDidUpdate() {
    this.update(this.props)
  }

  componentWillReceiveProps(nextProps) {
    this.update(nextProps)
  }

  update = (props) => {
    if(this.data.currentUser && this.data.currentUser.objectId !== this.prevUser && !props.auth.isFetchingRole) {
      this.prevUser = this.data.currentUser.objectId
      props.actions.auth.getUserRole(this.data.currentUser.objectId)
    }
  }

  render () {
    var navigationRight
    if(this.data.currentUser) {
      navigationRight = [
        this.props.auth.role === 'superadmin' || this.props.auth.role === 'admin' ? 
          <li className='proto-Nav-Item' key='dashboard'><Link className='btn' to="/dashboard">Dashboard</Link></li> 
          : null,
        <li className='proto-Nav-Item' key='history'><Link className='btn' to="/history">Historique</Link></li>,
        <li className='proto-Nav-Item' key='user'><Link className='btn' to="/account">{this.data.currentUser.name}</Link></li>,
        <li className='proto-Nav-Item' key='logout'><a className="btn logout-Item" onClick={this.logout}>Déconnexion</a></li>
      ]
    } else {
      navigationRight = null
    }

    return (
      <div>
        <div className="proto-Header white">
          <div className="container">
            <div className="clearfix mxn2">
              <div className="proto-Logo sm-col sm-col-3 px2">
                <div className="proto-Logo-Item">
                  <Link className='py2' to="/simulator/new">Page d'accueil</Link>
                </div>
              </div>
              <div className="proto-Nav sm-col sm-col-8 sm-col-right right-align px2">
                <ul className="proto-Nav-Items">{navigationRight}</ul>
              </div>
            </div>
          </div>
        </div>
        <div className="hero-Section center px3 white bg-gray bg-cover bg-center"
          style={styles.hero}>
          <h1 className="header-Title h0-responsive caps mt4 mb0 regular">Epsilog Simulation</h1>
          <p className="h3 hero-Sub">Simulez votre prochaine commande dès maintenant</p>
          <div className='logo-Container'>
            <img src={jg} />
          </div>
        </div>
      </div>
    )
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Header)
