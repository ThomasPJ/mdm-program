export default [
  {
    id: 0,
    name: 'Juniors (Trans)',
    maxQuantity: 1000, // = infinity
    models: [
      {
        name: 'AM 22/30',
        weight: 60
      },
      {
        name: 'EME 12',
        weight: 250
      },
      {
        name: 'EME 114',
        weight: 244
      },
      {
        name: 'EJE 112i',
        weight: 285
      },
      {
        name: 'EJE 116',
        weight: 439
      },
      {
        name: 'EJE 118',
        weight: 441
      },
      {
        name: 'EJE 120',
        weight: 441
      },
      {
        name: 'EJE C20',
        weight: 690
      },
      {
        name: 'EJE 220',
        weight: 540
      },
      {
        name: 'EJE 225',
        weight: 647
      },
      {
        name: 'EJE 230',
        weight: 580
      },
      {
        name: 'EJE 235',
        weight: 647
      },
      {
        name: 'ELS 18',
        weight: 600
      },
      {
        name: 'ERE 120',
        weight: 432
      },
      {
        name: 'ERE 220',
        weight: 800
      },
      {
        name: 'ERE 225',
        weight: 850
      },
      {
        name: 'ESE 120',
        weight: 857
      },
      {
        name: 'ESE 220',
        weight: 1062
      },
      {
        name: 'ESE 320',
        weight: 1074
      },
      {
        name: 'ESE 533',
        weight: 3700
      },
      {
        name: 'ERE 120 PR',
        weight: 700
      },
      {
        name: 'ERE 120 PF',
        weight: 700
      },
      {
        name: 'ERE 224',
        weight: 800
      },
      {
        name: 'EZS 130',
        weight: 560
      },
      {
        name: 'EZS C40',
        weight: 1185
      },
      {
        name: 'EZS 350',
        weight: 976
      },
      {
        name: 'ESE 220',
        weight: 1000
      },
      {
        name: 'ESE 430',
        weight: 2500
      }
    ]
  },
  {
    id: 1,
    name: 'Juniors (Gerb.)',
    maxQuantity: 1000, // = infinity
    models: [
      {
        name: 'HC 110',
        weight: 435
      },
      {
        name: 'EMC 10',
        weight: 600
      },
      {
        name: 'EMC 110',
        weight: 545
      },
      {
        name: 'EMC B10',
        weight: 590
      },
      {
        name: 'EMB 10',
        weight: 700
      },
      {
        name: 'EJC 110',
        weight: 750
      },
      {
        name: 'EJC 112',
        weight: 830
      },
      {
        name: 'EJC 212',
        weight: 980
      },
      {
        name: 'EJC 214',
        weight: 1039
      },
      {
        name: 'EJC 216',
        weight: 1044
      },
      {
        name: 'EJC 220',
        weight: 1207
      },
      {
        name: 'EJC B12',
        weight: 1065
      },
      {
        name: 'EJC B14',
        weight: 1146
      },
      {
        name: 'EJC B16',
        weight: 1146
      },
      {
        name: 'EJC B20',
        weight: 1322
      },
      {
        name: 'ERC 212/214/216',
        weight: 1230
      },
      {
        name: 'ERC 220',
        weight: 1310
      },
      {
        name: 'ESC 214',
        weight: 1590
      },
      {
        name: 'ESC 316',
        weight: 1746
      },
      {
        name: 'EJD 220',
        weight: 945
      },
      {
        name: 'ERD 220',
        weight: 1186
      },
      {
        name: 'EJC Z 14',
        weight: 1100
      },
      {
        name: 'EJC Z 16',
        weight: 1100
      },
      {
        name: 'EJB / EJC B 14',
        weight: 1200
      },
      {
        name: 'EJC / EJC B 16',
        weight: 1200
      },
      {
        name: 'ERC 14 ZT',
        weight: 1300
      },
      {
        name: 'ERC Z 14',
        weight: 1300
      },
      {
        name: 'EJD 220',
        weight: 950
      },
      {
        name: 'ERD 220',
        weight: 1200
      }
    ]
  },
  {
    id: 2,
    name: 'VFG Frontaux',
    maxQuantity: 4,
    models: [
      {
        name: 'EFG 110',
        weight: 2600
      },
      {
        name: 'EFG 113',
        weight: 2900
      },
      {
        name: 'EFG 115',
        weight: 2900
      },
      {
        name: 'EFG 213',
        weight: 2733
      },
      {
        name: 'EFG 215',
        weight: 2978
      },
      {
        name: 'EFG 216K',
        weight: 3000
      },
      {
        name: 'EFG 216',
        weight: 3057
      },
      {
        name: 'EFG 218K',
        weight: 3300
      },
      {
        name: 'EFG 218',
        weight: 3207
      },
      {
        name: 'EFG 220',
        weight: 3382
      },
      {
        name: 'EFG 316K',
        weight: 3100
      },
      {
        name: 'EFG 316',
        weight: 3001
      },
      {
        name: 'EFG 318K',
        weight: 3200
      },
      {
        name: 'EFG 318',
        weight: 3141
      },
      {
        name: 'EFG 320',
        weight: 3306
      },
      {
        name: 'EFG 425',
        weight: 4770
      },
      {
        name: 'EFG 430',
        weight: 5220
      },
      {
        name: 'EFG 535K',
        weight: 5830
      },
      {
        name: 'EFG 540',
        weight: 6600
      },
      {
        name: 'EFG 550',
        weight: 7300
      }
    ]
  },
  {
    id: 3,
    name: 'PREPA. CDES',
    maxQuantity: 4,
    models: [
      {
        name: 'ECE 220',
        weight: 1200
      },
      {
        name: 'ECE 225',
        weight: 1114
      },
      {
        name: 'ECE 310',
        weight: 1244
      },
      {
        name: 'ECE 320',
        weight: 1480
      },
      {
        name: 'ECD 320',
        weight: 2073
      },
      {
        name: 'EKS 110',
        weight: 1756
      },
      {
        name: 'EKS 210',
        weight: 2950
      },
      {
        name: 'EKS 310',
        weight: 3500
      },
      {
        name: 'EKS 312',
        weight: 3750
      },
      {
        name: 'EKS 513',
        weight: 6500
      },
      {
        name: 'EKS 515',
        weight: 8000
      },
      {
        name: 'EKX 410',
        weight: 7700
      }
    ]
  },
  {
    id: 4,
    name: 'RETRAKS',
    maxQuantity: 3,
    models: [
      {
        name: 'ETV 110',
        weight: 2560
      },
      {
        name: 'ETV 112',
        weight: 2580
      },
      {
        name: 'ETV 114',
        weight: 3000
      },
      {
        name: 'ETV 214',
        weight: 2975
      },
      {
        name: 'ETV 216',
        weight: 3110
      },
      {
        name: 'ETV 318',
        weight: 3522
      },
      {
        name: 'ETV C 16',
        weight: 3640
      },
      {
        name: 'ETV C20',
        weight: 4010
      },
      {
        name: 'ETV 220',
        weight: 3700
      },
      {
        name: 'ETV 320',
        weight: 3650
      },
      {
        name: 'ETV 325',
        weight: 3700
      },
      {
        name: 'ETV Q 20',
        weight: 4060
      },
      {
        name: 'ETV Q 25',
        weight: 4200
      },
      {
        name: 'ETM 214',
        weight: 2975
      },
      {
        name: 'ETM 216',
        weight: 3110
      }
    ]
  },
  {
    id: 5,
    name: 'THERMIQUES',
    maxQuantity: 4,
    models: [
      {
        name: 'TFG/DFG 316 s',
        weight: 2800
      },
      {
        name: 'TFG/DFG 320 s',
        weight: 3100
      },
      {
        name: 'TFG/DFG 425 s',
        weight: 4080
      },
      {
        name: 'TFG/DFG 430 s',
        weight: 4376
      },
      {
        name: 'TFG/DFG 435 s',
        weight: 4821
      },
      {
        name: 'DFG 316',
        weight: 2870
      },
      {
        name: 'TFG 316',
        weight: 2840
      },
      {
        name: 'DFG 320',
        weight: 3280
      },
      {
        name: 'TFG 320',
        weight: 3250
      },
      {
        name: 'TFG/DFG 325',
        weight: 4300
      },
      {
        name: 'TFG/DFG 430',
        weight: 4700
      },
      {
        name: 'TFG/DFG 540',
        weight: 6300
      },
      {
        name: 'TFG/DFG 60',
        weight: 11000
      },
      {
        name: 'TFG/DFG 70',
        weight: 12000
      },
      {
        name: 'TFG/DFG 80',
        weight: 12000
      },
      {
        name: 'TFG/DFG 90',
        weight: 16000
      }
    ]
  },
  {
    id: 6,
    name: 'Mâts verticaux',
    maxQuantity: 1000, // = infinity
    models: [
      {
        name: 'Star 8',
        weight: 2700
      },
      {
        name: 'Star 10',
        weight: 2760
      }
    ]
  },
  {
    id: 7,
    name: 'Plates-formes ciseaux électriques',
    maxQuantity: 1000, // = infinity
    models: [
      {
        name: 'Compact 8W',
        weight: 1950
      },
      {
        name: 'Compact 10',
        weight: 2330
      },
      {
        name: 'Compact 12',
        weight: 2630
      }
    ]
  }
]
