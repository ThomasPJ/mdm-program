import React                  from 'react';
import Directions             from 'components/Simulator/InputComponents/Directions';
import CargoList             from 'components/Simulator/InputComponents/CargoList';
import { connect }            from 'react-redux'
import { bindActionCreators } from 'redux'
import calculatorActions      from 'actions/calculator';

const mapStateToProps = (state) => ({

})
const mapDispatchToProps = (dispatch) => ({
  actions : bindActionCreators(calculatorActions, dispatch)
})

export class Inputs extends React.Component {

  static contextTypes = {
    simulationId: React.PropTypes.string
  }

  handle24hChange = (e) => {
    this.props.actions.updateIs24h(this.context.simulationId, e.target.checked)
  }

  render = () => {

    return (
      <div className=''>
        <Directions />
        <CargoList />
        <div className="input-Row sm-col sm-col-12 delivery-Container">
          <div className="input-Item sm-col sm-col-3">
            <label className="form-delivery block mb2">
              <input type="checkbox" onChange={this.handle24hChange}/>
              <span>Livraison en 24h</span>
            </label>
          </div>
        </div>
      </div>
    );
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Inputs)
