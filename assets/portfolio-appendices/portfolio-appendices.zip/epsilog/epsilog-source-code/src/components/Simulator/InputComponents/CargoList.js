import React                  from 'react';
import classNames             from 'classnames';
import calculatorActions      from 'actions/calculator';
import { connect }            from 'react-redux'
import { bindActionCreators } from 'redux'
import cargoModels       from '../cargoModels';

const mapStateToProps = (state) => ({
  calculator: state.calculator,
  routing: state.routing
})
const mapDispatchToProps = (dispatch) => ({
  actions : bindActionCreators(calculatorActions, dispatch)
})

export class CargoList extends React.Component {

  static contextTypes = {
    simulationId: React.PropTypes.string
  }

  displayNewCargoItem = () => {
    this.props.actions.addCargoItem(this.context.simulationId)
  }
  generateCargoItem = (cargo, i) => {
    var modelsDisplay
    var quantityDisplay

    if(cargo.type === -1) {
      modelsDisplay = []
      quantityDisplay = []
    } else {
      modelsDisplay = cargoModels[cargo.type].models.map((model, i) => <option key={model.name} value={i}>{model.name}</option>)
      quantityDisplay = [for (i of Array(10).keys()) i+1].map (i => (
          <option key={i} value={i}>{i}</option>
      ))
    }

    var handleTypeChange = (e) => {
      const newType = parseInt(e.target.value)
      this.props.actions.changeItemType(this.context.simulationId, i, newType)
    }

    var handleModelChange = (e) => {
      const newModel = parseInt(e.target.value)
      this.props.actions.changeItemModel(this.context.simulationId, i, newModel)
    }

    var handleQuantityChange = (e) => {
      const newQuantity = parseInt(e.target.value)
      this.props.actions.changeItemQuantity(this.context.simulationId, i, newQuantity)
    }

    var deleteCargoItem = () => {
      this.props.actions.removeCargoItem(this.context.simulationId, i)
    }

    return (

      <div className='table-Row' key={i}>
        <div className="input-Item sm-col sm-col-3 mr3">
          <select className="block field" value={cargo.type} onChange={handleTypeChange}>
            <option value={-1}>Sélectionner</option>
            {cargoModels.map(type => <option key={type.name} value={type.id}>{type.name}</option>)}
          </select>
        </div>
        <div className="input-Item sm-col sm-col-3 mr3">
          <select className="block field" value={cargo.model} onChange={handleModelChange}>
            <option value={-1}>Sélectionner</option>
            {modelsDisplay}
          </select>
        </div>
        <div className="input-Item sm-col sm-col-3 mr1">
          <select className="block field" value={cargo.quantity} onChange={handleQuantityChange}>
            <option value={0}>Sélectionner</option>
            {quantityDisplay}
          </select>
        </div>
        <div className="input-Item sm-col weight-Tag">
          {cargo.type!==-1&&cargo.model!==-1&&cargo.quantity!==0? cargo.quantity * cargoModels[cargo.type].models[cargo.model].weight : '0'} kg
        </div>
        <div className="input-Item sm-col delete-Tag">
          <a className='delete-Button' onClick={deleteCargoItem}>Supprimer</a>
        </div>
      </div>

    )
  }

  render () {

    const simulation = this.props.calculator[this.context.simulationId]
    if(!simulation) {
      return null
    }
    var cargoItems = simulation.cargoItems.map(this.generateCargoItem)

    return (
      <div>
        <div>
          <div className="input-Item sm-col sm-col-3 mr3">
            <label>Type</label>
          </div>
          <div className="input-Item sm-col sm-col-3 mr3">
            <label>Modèle</label>
          </div>
          <div className="input-Item sm-col sm-col-3">
            <label>Quantité</label>
          </div>
        </div>
        <div className='sm-col sm-col-12'>
          {cargoItems}
        </div>
        <div className='table-Add-Button sm-col sm-col-12'>
          <button onClick={this.displayNewCargoItem} className='btn btn-outline mb1 black'>+ Ajouter une référence</button>
        </div>
      </div>
    );
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(CargoList)
