import Parse from 'parse'
import {pluck, sum, last, isEmpty, groupBy, prop, lt, any, identity, apply, assoc, toPairs, map, compose, lte, filter, __, curry} from 'ramda';
import cargoModels       from './cargoModels';

const simpleTable = [
  [60,60,60,60,60,80,90,90,120,130,160,180],
  [70,70,70,70,70,100,110,115,120,130,180,230],
  [100,100,100,100,100,120,150,170,200,240,285,350],
  [110,110,110,110,110,120,150,170,200,240,285,350],
  [200,200,200,200,200,220,250,300,415,460,610,1075]
]

const complexTable = [
  [89,89,95,98,100,125,145,160,190,241,300,340],
  [110,110,110,110,112,180,240,280,400,400,480,624],
  [110,110,110,110,112,180,240,280,400,400,480,624],
  [220,220,220,220,220,351,468,546,780,780,936,1600]
]

const simpleWeights =
  [1000, 2500, 3500, 5000, 24000]
const complexWeights =
  [2500, 3500, 5000, 24000]

const distances =
  [10, 20, 30, 40, 50, 70, 100, 150, 200, 250, 500, 900]

const getDiscount = chariots => {
  switch(chariots) {
    case 0:
    case 1:
      return 0;
    case 2:
      return 0.25;
    case 3:
      return 0.35;
    default:
      return 0.45;
  }
}

const getSurcharge = (tariffIsComplex, weight, distance, is24hour) => {
  if(!is24hour) {
    return 0
  }

  if(tariffIsComplex && distance >= 50000) {
    return 0.5
  } else if(!tariffIsComplex && weight > 1000) {
    return 0.15
  }
  return 0
}

const sumWeight = cargoItems => sum(cargoItems.map(cI => {
  if(cI.type < 0 || cI.model < 0) return 0
  return cargoModels[cI.type].models[cI.model].weight * cI.quantity
}))
const sumQuantity = cargoItems => sum(pluck('quantity')(cargoItems))

var distancesCache = []
const getDistance = (origin, destination, cb) => {
  var cache = distancesCache[(origin+destination)]
  if(cache)
    return Promise.resolve(cache)
  else {
    var promise = Parse.Cloud.run('distance', {origin, destination})
    promise.then(distance => {
      distancesCache[(origin+destination)] = distance
    })
    return promise
  }
}

// Returns true if quantity is exceeded for any type
// [CargoItem] -> Boolean
const checkQuantityByType = (cargoItems) => {

  // Filter out cargo items with unspecified type
  // [CargoItem] -> [CargoItem]
  const filteredCIs = filter(compose(lte(0), prop('type')), cargoItems)

  // Group cargoItems by type
  // [CargoItem] -> {String: [CargoItem]}
  const quantityByType = groupBy(prop('type'), filteredCIs)

  // Generate array of arrays where left side is maxQuantity,
  // right side is actual quantity
  // {String: [CargoItem]} -> [[Int,Int]]
  const comparisons = map(([t, cIs])=> [cargoModels[parseInt(t)].maxQuantity, sumQuantity(cIs)], toPairs(quantityByType))

  // Check if max quantity is exceeded, for each type
  // i.e left side < right side
  // [[Int,Int]] -> [Boolean]
  const checks = map(apply(lt), comparisons)

  // check if any is true (exceeded)
  // [Boolean] -> Boolean
  return any(identity)(checks)
}

const calculate = (tariffIsComplex, origin, destination, is24hour, cargoItems, cb) => {
  const weight = sumWeight(cargoItems)
  const quantity = sumQuantity(cargoItems)

  var errors = {}

  if(origin === '') {
    errors = assoc('origin', true, errors)
  }
  if(destination === '') {
    errors = assoc('destination', true, errors)
  }
  if(checkQuantityByType(cargoItems)) {
    errors = assoc('maxQuantity', true, errors)
  }

  if(!isEmpty(errors)) {
    return cb(errors, 0, 0, weight, 0)
  }

  getDistance(origin, destination).then(distance => {
    if(quantity === 0) {
      errors.quantity = true
    }

    const discount = getDiscount(quantity)
    const totalPrice = sum(map(calculatePerItem(__, distance, quantity, discount, tariffIsComplex, is24hour), cargoItems))
    const isSurcharged = any(s => s > 0)(map( getSurchargeForCargoItem(__, distance, tariffIsComplex, is24hour), cargoItems))
    const priceRounded = +(totalPrice.toFixed(2))
    return cb({}, priceRounded, distance, weight, discount, isSurcharged)
  })
}

const calculatePerItem = curry((cI, distance, quantity, discount, tariffIsComplex, is24hour) => {
  var errors = {}
  // Get weight of individual item
  if(cI.type < 0 || cI.model < 0) return 0
  const weight = cargoModels[cI.type].models[cI.model].weight

  const weights = tariffIsComplex ? complexWeights : simpleWeights
  const table = tariffIsComplex ? complexTable : simpleTable

  const weightIndex = weights.findIndex (w => weight <= w )
  const distanceIndex = distances.findIndex (d => (distance / 1000) <= d )
  
  if(weightIndex === -1) {
    errors.weight = true
  }
  if(distanceIndex === -1) {
    errors.distance = true
  }

  if(!isEmpty(errors)) {
    return 0
  }

  const surcharge = getSurchargeForCargoItem(cI, distance, tariffIsComplex, is24hour)
  return table [weightIndex] [distanceIndex] * (1 - discount) * (1 + surcharge) * cI.quantity
})

const getSurchargeForCargoItem = curry((cI, distance, tariffIsComplex, is24hour) => {
  // Get weight of individual item
  if(cI.type < 0 || cI.model < 0) return 0
  const weight = cargoModels[cI.type].models[cI.model].weight

  const surcharge = cI.quantity > 0 ? getSurcharge(tariffIsComplex, weight, distance, is24hour) : 0
  return surcharge
})

const maxWeight = tariffIsComplex => {
  const weights = tariffIsComplex ? complexWeights : simpleWeights
  return last(weights)
}

const maxDistance = () => {
  return last(distances)
}

export default {calculate, maxWeight, maxDistance}