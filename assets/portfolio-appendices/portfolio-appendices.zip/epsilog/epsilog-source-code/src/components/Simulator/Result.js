import React                  from 'react';
import { connect }            from 'react-redux';
import {calculate, maxWeight, maxDistance} from './Calculator';
import ParseReact             from 'parse-react';
import calculatorActions      from 'actions/calculator';
import { updatePath }         from 'redux-simple-router'
import { bindActionCreators } from 'redux'
import Parse                  from 'parse'
import {assoc,compose, filter} from 'ramda'
import classNames             from 'classnames'
import randomString           from 'lib/randomString'

const mapStateToProps = (state) => ({
  calculator: state.calculator,
  routing: state.routing
})
const mapDispatchToProps = (dispatch) => ({
  actions : bindActionCreators(calculatorActions, dispatch),
  updatePath : bindActionCreators(updatePath, dispatch)
})
export class Result extends React.Component {

  static contextTypes = {
    simulationId: React.PropTypes.string
  }

  state = {
    errors: {},
    distance: 0,
    price: 0,
    weight: 0,
    discount: 0,
    isSurcharged: false
  }

  calculatePrice = () => {
    const simulationId = this.context.simulationId
    const simulation = this.props.calculator[simulationId]

    const {tariff, origin, destination, is24h, cargoItems} = simulation
    calculate(tariff, origin, destination, is24h, cargoItems, (errors, price, distance, weight, discount, isSurcharged) => {
      if(errors) {
        this.setState({errors, price, distance, weight, discount, isSurcharged})
      }
      else if (price !== this.state.price)
      this.setState({errors, price, distance, weight, discount, isSurcharged})
    })
  }

  componentDidUpdate(prevProps) {
    const simulationId = this.context.simulationId
    const simulation = this.props.calculator[simulationId]
    const prevSimulation = prevProps.calculator[simulationId]
    if(prevSimulation !== simulation)
      this.calculatePrice()
  }

  componentDidMount() {
    this.calculatePrice()
  }

  reset = () => {
    const simulationId = this.context.simulationId
    this.props.actions.reset(simulationId)
  }

  checkCargoItemComplete = cargoItem =>
    cargoItem.type !== -1 &&
    cargoItem.model !== -1 &&
    cargoItem.quantity !== 0

  removeIncompleteCargoItems = cargoItems => filter(this.checkCargoItemComplete, cargoItems)



  save = () => {
    const simulationId = this.context.simulationId
    const simulation = this.props.calculator[simulationId]
    const data = {
      tariff:  simulation.tariff,
      is24h: simulation.is24h,
      origin: simulation.origin,
      destination: simulation.destination,
      price: this.state.price,
      distance: this.state.distance,
      cargoItems: this.removeIncompleteCargoItems(simulation.cargoItems)
    }

    // Create ParseReact Mutation
    var mutation
    if(simulationId === 'new') {
      const currentUser = Parse.User.current()
      const acl = new Parse.ACL(currentUser);
      acl.setRoleReadAccess('superadmin', true)
      acl.setRoleWriteAccess('superadmin', true)
      acl.setRoleReadAccess('admin', true)
      //Add user column and ACL
      const data2 = compose(
        assoc('ACL', acl),
        assoc('token', randomString(16)),
        assoc('author', currentUser))
      (data)
      mutation = ParseReact.Mutation.Create('Simulation', data2)
    } else {
      var Simulation = Parse.Object.extend('Simulation')
      var s = new Simulation
      s.objectId = simulationId
      mutation = ParseReact.Mutation.Set(s, data)
    }

    mutation.dispatch().then(newSimulation => {
      this.props.updatePath(`/history?newSimulationId=${newSimulation.id.objectId}`)
    })
  }

  render () {
    const simulationId = this.context.simulationId
    const simulation = this.props.calculator[simulationId]
    if(!simulation) {
      return null
    }

    const tariff = simulation.tariff !== null ?
      <li className='criteria-List-Item'>Tarif : {simulation.tariff ? 'Complexe' : 'Simple'}</li>
    : null
    const distance = this.state.distance ?
      <li className='criteria-List-Item'>Distance : {Math.round(this.state.distance / 1000) + 'km (' + simulation.origin + ' - ' + simulation.destination + ')'}</li>
    : null
    const livraison24h = simulation.is24h ?
      <li className='delivery-Item criteria-List-Item'>Livraison en 24h</li>
    : null
    const surcharge = this.state.isSurcharged ?
      (simulation.tariff ?
        <li className='delivery-subItem'>(Taux additionnel de 50% pour toute distance supérieure ou égale à 50km - inclus dans le prix total)</li>
        : <li className='delivery-subItem'>(Taux additionnel de 15% pour les modèles ayant un poids supérieur à 1 tonne - inclus dans le prix total)</li>)
    : null
    const discount = this.state.discount ?
      <div>
        <div>Réduction de {Math.round(this.state.discount * 100)}%</div>
        <div>(incluse dans le prix total)</div>
      </div>
    : null

    return (
      <div>
        <div className='sm-col sm-col-6'>
          <div className='home-Criteria-Block'>
            <label>Critères</label>
            <ul className='criteria-List'>
              {tariff}
              {distance}
              {livraison24h}
              {surcharge}
            </ul>
            { this.state.errors.maxQuantity ?
              <div className="red">Poids maximal dépassé, pour les cotations sur demande veuillez nous contacter</div> :
              null }
          </div>
        </div>
        <div className='sm-col sm-col-6'>
          <div className='right-align'>
            <label>Distance</label>
            <div className={classNames({'tag-Item' : true, red: this.state.errors.distance})}>{this.state.distance === false ? '-' : Math.round(this.state.distance/1000)} km</div>
            {this.state.errors.distance ? <div className="red">Trop loin (max. {Math.round(maxDistance()/1000)} km)</div> : null}
          </div>
          <div className='right-align'>
            <label>Poids total</label>
            <div className={classNames({'tag-Item' : true, red: this.state.errors.weight})}>{this.state.weight === false ? '-' : this.state.weight} kg</div>
            {this.state.errors.weight ? <div className="red">Poids maximal dépassé <br/> (max. {maxWeight(simulation.tariff)} kg)</div> : null}
          </div>
          <div className='right-align'>
            <label>Total</label>
            <div className='tag-Item'>{this.state.price === false ? '-' : this.state.price} €</div>
          </div>
          <div className='right-align'>
            <div className='price-Tag-Item discount-Tag'>{discount}</div>
          </div>
        </div>
        <div className='sm-col sm-col-12'>
          <ul className='result-Options center'>
            <li><a className='btn' to="" onClick={this.reset}>Réinitialiser</a></li>
            <li><a className='btn' onClick={this.save}>Sauvegarder</a></li>
          </ul>
        </div>
        <div className='validate-Container sm-col sm-col-12 center display-none'>
          <a className='btn btn-primary' to=''>Valider la commande</a>
        </div>
      </div>
    );
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Result)
