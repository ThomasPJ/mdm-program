import React                  from 'react';
import { Link }               from 'react-router';
import ep                   from 'img/ep.png'

export class Footer extends React.Component {

  render () {

    return (
      <footer className="proto-Footer white">
        <div className='container'>
          <div className='clearfix'>
            <div className='sm-col sm-col-12'>
              <ul className='proto-Footer-Items'>
                <li className='proto-Footer-Item'><Link className='' to="/mentions-legales">CGU</Link></li>
                <li className='proto-Footer-Item'><a className='' target='_blank' href="http://epsilog.eu/">Epsilog.eu</a></li>
                <li className='proto-Footer-Item'><a className='' href="mailto:epsilogtransportoccasion@epsilog.eu">Contact</a></li>
              </ul>
            </div>
            <div className='sm-col sm-col-12'>
              <div className='ep-Logo'>
                <img src={ep} />
              </div>
            </div>
          </div>
        </div>
      </footer>
    );
  }
}

export default Footer
