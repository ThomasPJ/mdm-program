import React from 'react';
import 'styles/core.scss';
import Header from '../components/Header';
import Footer from '../components/Footer';

export default class CoreLayout extends React.Component {
  static propTypes = {
    children : React.PropTypes.element
  }

  render () {
    return (
      <div className='page-view'>
        <Header />
        <div className='body-view'>
          {this.props.children}
        </div>
        <Footer />
      </div>
    );
  }
}
