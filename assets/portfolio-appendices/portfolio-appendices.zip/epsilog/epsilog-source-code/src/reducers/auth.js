import { createReducer }     from '../utils';
import { COUNTER_INCREMENT } from 'constants/counter';
import update                from 'react-addons-update'
import {isNil}               from 'ramda'

const initialState = {
  role: 'user',
  isFetchingRole: false
};
export default createReducer(initialState, {
  GET_USER_ROLE_REQUEST : (state) => update(state, {
    'role': {
      '$set': 'user'
    },
    isFetchingRole: {
      '$set': true
    }
  }),

  GET_USER_ROLE_SUCCESS : (state, payload) => {
    let newRole = isNil(payload) ? 'user' : payload.toJSON().name
    return update(state, {
      'role': {
        '$set': newRole
      },
      isFetchingRole: {
        '$set': false
      }
    })
  }
});
