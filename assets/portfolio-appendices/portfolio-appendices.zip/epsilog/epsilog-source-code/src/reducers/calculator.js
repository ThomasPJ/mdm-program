import { createReducer }     from '../utils';
import update                from 'react-addons-update'

const emptyCargoItem = {
  type: -1,
  model: -1,
  quantity: 0
}
const initialState = {
  'new' : {
    tariff : false,
    is24h: null,
    origin: '',
    destination: '',
    cargoItems: [emptyCargoItem],
    displayErrors: false
  }
};
export default createReducer(initialState, {
  'RESET' : (state, payload) => {
    const newState = update(state, {
      [payload.simulationId] : {
        $set: initialState['new']
      }
    })
    return newState
  },
  'RESTORE' : (state, payload) => {
    const newState = update(state, {
      [payload.simulationId] : {
        $set: payload.simulation
      }
    })
    return newState
  },
  'REMOVE' : (state, payload) => {
    const newState = update(state, {
      [payload.simulationId] : {
        $set: undefined
      }
    })
    return newState
  },
  'SET_ORIGIN' : (state, payload) => {
    const newState = update(state, {
      [payload.simulationId] : {
        origin: {
          $set: payload.origin
        }
      }
    })
    return newState
  },
  'SET_DESTINATION' : (state, payload) => {
    const newState = update(state, {
      [payload.simulationId] : {
        destination: {
          $set: payload.destination
        }
      }
    })
    return newState
  },
  'ADD_CARGO_ITEM' : (state, payload) => {
    const newState = update(state, {
      [payload.simulationId] : {
        cargoItems: {
          $push: [emptyCargoItem]
        }
      }
    })
    return newState
  },
  'REMOVE_CARGO_ITEM' : (state, payload) => {
    const newState = update(state, {
      [payload.simulationId] : {
        cargoItems: {
          $splice: [[payload, 1]]
        }
      }
    })
    return newState
  },
  'CHANGE_ITEM_TYPE' : (state, payload) => {
    const newState = update(state, {
      [payload.simulationId] : {
        cargoItems: {
          [payload.i] : {
            type: {
              $set: payload.type
            },
            model: {
              $set: emptyCargoItem.model
            },
            quantity: {
              $set: emptyCargoItem.quantity
            }
          }
        }
      }
    })
    return newState
  },
  'CHANGE_ITEM_MODEL' : (state, payload) => {
    const newState = update(state, {
      [payload.simulationId] : {
        cargoItems: {
          [payload.i] : {
            model: {
              $set: payload.model
            }
          }
        }
      }
    })
    return newState
  },
  'CHANGE_ITEM_QUANTITY' : (state, payload) => {
    const newState = update(state, {
      [payload.simulationId] : {
        cargoItems: {
          [payload.i] : {
            quantity: {
              $set: payload.quantity
            }
          }
        }
      }
    })
    return newState
  },
  'UPDATE_TARIFF' : (state, payload) => {
    const newState = update(state, {
      [payload.simulationId]: {
        tariff: {
          $set: payload.isComplex
        }
      }
    })
    return newState
  },
  'UPDATE_IS24H' : (state, payload) => {
    const newState = update(state, {
      [payload.simulationId]: {
        is24h: {
          $set: payload.is24h
        }
      }
    })
    return newState
  }
});
