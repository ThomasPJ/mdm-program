import React                  from 'react';
import Simulation             from 'components/Simulation/Simulation'
import Parse                  from 'parse'

const mapStateToProps = (state) => ({
  
})
const mapDispatchToProps = (dispatch) => ({
  
})


export class Share extends React.Component {

  state = {
    simulation: false
  }

  componentDidMount() {
    const simulationId = this.props.routeParams.simulationId
    const token = this.props.location.query.token
    Parse.Cloud.run('getSimulation', {simulationId, token})
      .then(simulation => {
        this.setState({simulation: simulation.toPlainObject()})
      })
  }

  render () {
    return (
      <div className='container'>
        <div className='clearfix'>
          <div className='sm-col sm-col-12'>
            { this.state.simulation ? 
              <Simulation key={this.props.routeParams.simulationId} simulation={this.state.simulation} isReadOnly={true} isShowAuthor={false}/> :
              null }
          </div>
        </div>
      </div>
    )
  }
}

export default Share
