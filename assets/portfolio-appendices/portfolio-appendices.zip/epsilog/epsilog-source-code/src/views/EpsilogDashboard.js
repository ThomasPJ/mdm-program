import React                  from 'react';
import { Link }               from 'react-router';

export class EpsilogDashboard extends React.Component {


  render () {
    return (
      <div className='container'>
        Epsilog Dashboard
      </div>
    );
  }
}

export default EpsilogDashboard
