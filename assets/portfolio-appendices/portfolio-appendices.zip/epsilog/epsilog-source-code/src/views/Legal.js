import React                  from 'react';
import { Link }               from 'react-router';

export class Legal extends React.Component {

  render () {
    return (
      <div className='container'>
        <div className='clearfix'>
          <div className='sm-col sm-col-12 mentions'>
            <h1>Conditions générales d'utilisation</h1>
            <hr></hr>
            <p>
              Comme indiqué avant la validation d'une simulation, toute utilisation du site epsilog-simultation.eu emporte acceptation des présentes Conditions Générales d'Utilisation dans leur dernière version.
            </p>
            <h2>Identification</h2>
            <p>
              Le service du site epsilog-similation.eu est fourni par :
            </p>
            <p>
              EPSILOG SAS au capital de 180 000 €<br/>
              31 BD des Nations - 69780 MIONS<br/>
              RCS LYON 392 165 080
            </p>
            <p>
              epsilog-simulation.eu  a été déclaré à la CNIL le 24 décembre 2015 sous le numéro 1916022 v 0
            </p>
            <h2>Définitions</h2>
            <p>
              <strong>Utilisateur JUNGHEINRICH :</strong> Cet outil est réservé aux collaborateurs internes de la société JUNGHEINRICH  qui recherchent une ou plusieurs simulations de prix pour la réalisation de prestations de transport par la SAS EPSILOG.
            </p>
            <p>
              <strong>Formulaire de simulation :</strong> pages du site à remplir par l'utilisateur JUNGHEINRICH pour qualifier sa demande de simulation.
            </p>
            <p>
              <strong>Simulation :</strong> Offre commerciale de type cotation décrivant le service, les conditions et le tarif proposé par la SAS EPSILOG à un utilisateur JUNGHEINRICH en réponse à une demande de simulation de prix.
            </p>
            <p>
              Les tarifs ne sont pas fermes, ils indiquent une estimation. Certaines particularités ne sont pas enregistrées sur l’outil de simulation (hauteur, transport en complet, catégories 5..), aussi le prix obtenu via la simulation ne pourra être considéré comme définitif que si tous les critères enregistrés pas l’utilisateur JUNGHEINRICH correspondent réellement et s’ils sont validés auprès des contacts habituels EPSILOG.
            </p>
            <p>
              <strong>Compte utilisateur JUNGHEINRICH :</strong> désigne le compte en ligne d'un utilisateur JUNGHEINRICH (Login) permettant un accès simplifié au service avec une mémorisation des informations saisies lors des demandes de simulation. La connexion au compte s'effectue par la saisie des coordonnées de connexion : email et mot de passe.
            </p>
            <h2>Description du service</h2>
            <p>
              Le site epsilog-simulation.eu propose un outil de simulation de prix.
              Pour obtenir la simulation de prix, l'utilisateur JUNGHEINRICH doit remplir un des formulaires de demande de devis correspondant au type de prestation de transport dont il a besoin.
            </p>
            <p>
              L'utilisateur JUNGHEINRICH pourra alors réinitialiser, sauvegarder ou valider la commande.
              L'utilisateur JUNGHEINRICH devra néanmoins se mettre directement en contact avec le service transport EPSILOG afin de finaliser son devis et, le cas échéant, réaliser la ou les prestations demandées. En effet le site epsilog-simulation.eu ne permet pas d'obtenir directement la confirmation du transport. Les devis sont réalisés par des professionnels se trouvant, lorsque c'est possible, à proximité du lieu de départ ou de destination de la prestation de transport demandée. Dans tous les cas, un contact par email ou par téléphone est nécessaire entre l'utilisateur JUNGHEINRICH et le service transport EPSILOG afin que ce dernier puisse établir un prix final.
            </p>
            <p>
              Le Site est en principe accessible 24 heures sur 24, et 7 jours sur 7. L'utilisateur JUNGHEINRICH déclare avoir pleine et entière conscience du fait que le service et le site peuvent ponctuellement faire l'objet d'opérations techniques de maintenance, d'entretien et de mise à jour, entraînant leur indisponibilité momentanée.
            </p>
            <h2>Coût du service</h2>
            <p>
              Le service de simulation de prix proposé par epsilog-simulation.eu est entièrement gratuit dans la mesure où il est destiné uniquement aux utilisateurs JUNGHEINRICH.
            </p>
            <h2>Engagements des utilisateurs JUNGHEINRICH</h2>
            <p>
              Les utilisateurs JUNGHEINRICH s'engagent à utiliser le service de simulation pour des demandes de prestations réelles et sérieuses et en aucun cas dans un but de mise en concurrence du tarif.
              Les utilisateurs JUNGHEINRICH s'engagent à indiquer dans leurs demandes de devis des informations exactes.
              Toute utilisation abusive des services et du site epsilog-simulation.eu pourra faire l'objet de poursuites judiciaires. Sont par exemple considérées comme abusives les demandes de simulation fantaisistes, ou usurpant l'identité d'une tierce personne.
            </p>
            <h2>Engagements et responsabilité d’epsilog-simulation.eu</h2>
            <p>
              Le site epsilog-simulation.eu ne saurait en aucun cas voir sa responsabilité engagée, directement ou indirectement, du fait des dysfonctionnements du Service causés par une ou plusieurs des caractéristiques techniques inhérentes au Réseau Internet, au matériel informatique ou aux logiciels utilisés par l'utilisateur JUNGHEINRICH, et ce pour quelque raison que ce soit.
            </p>
            <p>
              Le site epsilog-simulation.eu ne saurait garantir à l'utilisateur JUNGHEINRICH le secret de la correspondance des courriers électroniques ou de tout autre mode de communication utilisant le support du réseau Internet et pouvant être captés par un tiers du fait du mode de circulation des données sur ce réseau.
            </p>
            <p>
              La conservation, l'utilisation et la transmission des Coordonnées de connexion pour les utilisateurs JUNGHEINRICH ayant créé un compte utilisateur JUNGHEINRICH s'effectuent sous leur entière et unique responsabilité. Toute utilisation des Coordonnées de connexion sera présumée avoir été effectuée ou dûment autorisée par l'utilisateur JUNGHEINRICH.
            </p>
            <p>
              De plus, il appartient à chaque utilisateur JUNGHEINRICH de prendre toutes les mesures appropriées de façon à protéger ses propres données contre la contamination par d'éventuels virus circulant sur internet, et contre les intrusions dans son système informatique.
            </p>
            <h2>Données personelles</h2>
            <p>
              Les données personnelles fournies par les utilisateurs JUNGHEINRICH lors du passage d'une demande de simulation sont confidentielles.  Aucune donnée personnelle ne sera publiée sur Internet. Aucune donnée personnelle ne sera communiquée à des tiers sans accord préalable de l'utilisateur JUNGHEINRICH.
              Les fournisseurs s'engagent fermement, sous peine de poursuites à respecter ces règles pour les Conformément à la loi "informatique et libertés" du 6 janvier 1978, vous bénéficiez d'un droit d'accès et de rectification aux informations qui vous concernent. Si vous souhaitez exercer ce droit et obtenir communication des informations vous concernant, veuillez-vous adresser à EPSILOG 31 Bd des Nations – 69780 MIONS
            </p>
            <h2>Propriété intellectuelle</h2>
            <p>
              L'ensemble des contenus diffusés sur le site epsilog-simulation.eu (bases de données, logiciels, images, photographies, logos, marques, vidéos, sons, textes, analyses, graphiques, CGU...), ainsi que sa structure générale sont protégés par la législation française et internationale en vigueur en matière de propriété intellectuelle et notamment, le droit d'auteur, les droits voisins et le droit des marques.
              Les présentes Conditions Générales d'Utilisation n'accordent aux visiteurs, et utilisateurs JUNGHEINRICH aucune cession ou concession des droits de reproduction, de représentation et plus largement de communication au public quelle qu'en soit la forme, des éléments diffusés sur le site et de la structure générale de celui-ci, y compris pour les représentations graphiques.
              Visiteurs, utilisateurs JUNGHEINRICH sont uniquement autorisés par le site epsilog-simulation.eu à consulter ces éléments pour leur usage.
              Il est strictement interdit d'exploiter ces contenus et notamment de les reproduire, représenter, modifier ou adapter en tout ou partie.
            </p>
            <h2>Modification des Conditions Générales d'Utilisation</h2>
            <p>
              Les présentes Conditions Générales d'Utilisation sont consultables en permanence sur le Site. Le site epsilog-simulation.eu pourra mettre à jour et modifier les présentes Conditions Générales d'Utilisation, en fonction notamment de toute évolution légale, réglementaire ou technique, ainsi que de toute modification des fonctionnalités du Service. Dans ce cas, les Conditions Générales d'Utilisation modifiées entrent en vigueur à compter de leur mise en ligne. Loi applicable et tribunaux compétents
              Le présent contrat est soumis à l'application du droit français. En cas de litige survenant à l'occasion de l'interprétation, de l'exécution ou de la résiliation du présent contrat, il est attribué compétence exclusive aux juridictions du ressort du Tribunal de Lyon.
            </p>
          </div>
        </div>
      </div>
    );
  }
}

export default Legal
