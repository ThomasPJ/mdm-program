import React from 'react';
import { Link } from 'react-router';
import Inputs from 'components/Simulator/Inputs';
import Result from 'components/Simulator/Result';
import ParseReact             from 'parse-react';
import Parse                  from 'parse'
import calculatorActions      from 'actions/calculator';
import { connect }            from 'react-redux'
import { bindActionCreators } from 'redux'
const ParseComponent = ParseReact.Component(React);

const mapStateToProps = (state) => ({
})
const mapDispatchToProps = (dispatch) => ({
  actions : bindActionCreators(calculatorActions, dispatch)
})
export class ClientSimulator extends ParseComponent {

  observe(props, state) {
    const simulationId = props.routeParams.simulationId
    if(simulationId === 'new') {
      return {}
    }
    return {
      simulation: new Parse.Query('Simulation').observeOne(simulationId)
    }
  }

  static childContextTypes = {
    simulationId: React.PropTypes.string.isRequired
  }

  getChildContext = () => {
    return { simulationId: this.props.routeParams.simulationId };
  }

  isLoaded = false

  componentDidUpdate() {
    const simulationId = this.props.routeParams.simulationId
    if(this.data.simulation && !this.isLoaded) {
      this.props.actions.restore(simulationId, this.data.simulation)
      this.isLoaded = true
    }
  }

  render () {
    if(!this.data.simulation && this.props.routeParams.simulationId !== 'new') {
      return null
    }
    return (
      <div className='container'>
        <div className="clearfix mxn2">
          <div className="sm-col sm-col-12 input-Area">
            <Inputs />
          </div>
          <div className="sm-col sm-col-8 result-Main-Container">
            <Result />
          </div>
        </div>
      </div>
    );
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(ClientSimulator)
