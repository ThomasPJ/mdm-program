import React                  from 'react';
import { Link }               from 'react-router';
import ParseReact             from 'parse-react';
import Parse                  from 'parse'
import { connect }            from 'react-redux'
import { bindActionCreators } from 'redux'
import calculatorActions      from 'actions/calculator';
import cargoModels            from 'components/Simulator/cargoModels';
import { updatePath }         from 'redux-simple-router'
import moment                 from 'moment'
import fuzzysearch            from 'fuzzysearch'
import {any, curry, identity, isNil, uniq, pluck,compose} from 'ramda'
import {parse, parseDate}            from 'chrono-node'
import update                 from 'react-addons-update'
import Simulation             from 'components/Simulation/Simulation'
import search                     from 'img/search.svg'
const ParseComponent = ParseReact.Component(React);

const mapStateToProps = (state) => ({
  calculator: state.calculator
})
const mapDispatchToProps = (dispatch) => ({
  actions : bindActionCreators(calculatorActions, dispatch),
  updatePath : bindActionCreators(updatePath, dispatch)
})


var styles = {
  search: {
      backgroundImage: 'url(' + search + ')'
  }
}

export class Dashboard extends ParseComponent {

  observe(props, state) {
    return {
      simulations: new Parse.Query('Simulation').descending('createdAt').include(['author'])
    }
  }

  state = {
    keyword: '',
    company: false
  }

  search = () => {
    const keyword = this.state.keyword.toLowerCase()
    if(keyword === '' && !this.state.company) {
      return this.data.simulations
    }

    const curriedFuzzy = curry(fuzzysearch)
    const matchesKeyword = keyword === '' ? () => false : curriedFuzzy(keyword)

    const checkCargoItem = (keyword, cargoItem) => {
      const type = cargoModels[cargoItem.type]

      const typeName = type.name
      const model = type.models[cargoItem.model]
      const modelName = model.name

      const checks = [
        typeName.toLowerCase(),
        modelName.toLowerCase(),
      ]
      return any(matchesKeyword)(checks)
    }

    const checkIfDateMatch = (keyword, date) => {
      var cA = parse(date + '')[0].start

      if(parse(keyword)[0]) {
        var result = parse(keyword)[0].start
      }

      var checkComponent = (component, dateToCheck, certainDate) => {
        if(dateToCheck.isCertain(component)) {
          return dateToCheck.knownValues[component] === certainDate.knownValues[component]
        }
        return null
      }

      if(parse(keyword)[0]) {
        var result = parse(keyword)[0].start
        var checks = ['year', 'month', 'week', 'weekday', 'day', 'hour', 'minute'].map(c => {
          return checkComponent(c, result, cA)
        })
        return !any(c => c === false)(checks) && any(identity)(checks)
      }
      return false
    }

    const checkIfMatch = (keyword, simulation) => {
      const simulationChecks = [
        matchesKeyword(simulation.origin.toLowerCase()),
        matchesKeyword(simulation.destination.toLowerCase()),
        checkIfDateMatch(keyword, simulation.createdAt),
        any(curry(checkCargoItem)(keyword))(simulation.cargoItems),
        this.state.company ? this.state.company === simulation.author.company : false
      ]
      return any(identity)(simulationChecks)
    }

    return this.data.simulations.filter(curry(checkIfMatch)(keyword))
  }

  handleSearchChange = (e) => {
    const keyword = e.target.value
    this.setState({keyword})
  }

  handleCompanyChange = (e) => {
    const company = e.target.value
    this.setState({company})
  }

  uniqueCompanies = () => {
    if(isNil(this.data.simulations)) {
      return []
    }
    return uniq(compose(pluck('company'), pluck('author'))(this.data.simulations))
  }

  render () {
    return (
      <div className='container'>
        <div className='clearfix'>
          <div className='sm-col sm-col-12'>
            <div className='search-Box sm-col sm-col-4'>
              <label>Agence</label>
              <select className="block field" value={this.state.company} onChange={this.handleCompanyChange}>
                <option value={-1}>Sélectionner</option>
                {this.uniqueCompanies().map(c => <option value={c} key={c}>{c}</option>)}
              </select>
              <label>Recherchez une simulation</label>
              <input style={styles.search} type='text' placeholder='Date (jj/mm/aaaa), type, modèle' className='field' onChange={this.handleSearchChange}></input>
            </div>
          </div>
          <div className='sm-col sm-col-12'>
            <div className='history-Items'>
              {this.search().map(simulation => <Simulation key={simulation.id.objectId} simulation={simulation} isReadOnly isShowAuthor />)}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Dashboard)
