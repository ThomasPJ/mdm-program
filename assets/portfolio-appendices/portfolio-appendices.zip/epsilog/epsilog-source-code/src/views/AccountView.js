import React                  from 'react'
import classNames             from 'classnames'
import Parse                  from 'parse'
import ParseReact             from 'parse-react'
var ParseComponent = ParseReact.Component(React);

class AccountView extends ParseComponent {

  observe(props, state) {
    return {
      currentUser: ParseReact.currentUser
    }
  }

  state = {
    name: '',
    email: '',
    password: '',
    company: '',
    isSubmitted: false,
    isError: false,
    isLoaded: false,
    isSaved: false,
    disabled: true
  }

  onChange = (e, field) => {
    this.setState({
      [field]: e.target.value,
      isSaved: false,
      disabled: false
    })
  }

  setError = (isError) => {
    this.setState({
      isError: isError,
      isSaved: false
    })
  }

  register = (event) => {
    event.preventDefault()
    if(this.state.isSubmitted)
      return

    this.setState({
      isSubmitted: true
    })

    var user = this.data.currentUser
    var updatedData = {
     email: this.state.email,
     name: this.state.name,
     company: this.state.company ,
    }
    if(this.state.password !== '') {
      updatedData.password = this.state.password
    }

    ParseReact.Mutation.Set(user, updatedData)
      .dispatch()
      .then(user => {
      this.setState({
        isError: false,
        isSubmitted: false,
        isSaved: true
      })
    }, (user, error) => {
      this.setState({
        isError: true,
        isSubmitted: false
      })
    })
  }

  componentDidUpdate() {
    var user = this.data.currentUser
    if(user && !this.state.isLoaded) {
      this.setState({
        name: user.name,
        email: user.email,
        company: user.company,
        isLoaded: true
      })
    }
  }

  render () {
    if(!this.data.currentUser) {
      return null
    }

    var fieldClasses = classNames({
      'field': true,
      'col-12': true,
      'is-error':this.state.isError
    })

    var btnClasses = classNames({
      'btn': true,
      'btn-primary': true,
      'bg-green': this.state.isSaved,
      'black bg-silver': this.state.disabled
    })


    var buttonText
    if(this.state.isSubmitted) {
      buttonText = 'En cours...'
    } else if(this.state.isSaved) {
      buttonText = 'A jour'
    } else {
      buttonText = 'Mettre à jour'
    }

    return (
      <div className='container px2'>
        <div className="clearfix">
          <div className="sm-col-4 mx-auto">
            <form onSubmit={this.register}>
              <h2>Compte</h2>
              <p>Mettez à jour vos coordonnées</p>
              <div className="mb2">
                <label>Nom</label>
                 <input
                  type="text"
                  className={fieldClasses}
                  placeholder="Nom"
                  value={this.state.name}
                  onChange={(e) => {this.onChange(e, 'name')}}/>
              </div>
              <div className="mb2">
                <label>Email</label>
                <input
                  type="text"
                  className={fieldClasses}
                  placeholder="Email"
                  onChange={(e) => {this.onChange(e, 'email')}}
                  value={this.state.email}
                   />
              </div>
              <div className="mb2">
                <label>Mot de passe</label>
                <input
                  type="password"
                  className={fieldClasses}
                  placeholder="Mot de passe"
                  onChange={(e) => {this.onChange(e, 'password')}}
                  value={this.state.password}/>
              </div>
              <div className="mb2">
                <label>Agence</label>
                <input
                  type="text"
                  className={fieldClasses}
                  placeholder="Agence"
                  value={this.state.company}
                  onChange={(e) => {this.onChange(e, 'company')}}/>
              </div>
              <div className="">
                <input type="submit" className={btnClasses} value={buttonText} disabled={this.state.disabled}/>
              </div>
            </form>
          </div>
        </div>
      </div>
    )
  }
}

export default AccountView
